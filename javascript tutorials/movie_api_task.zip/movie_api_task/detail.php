<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link rel="stylesheet" href="css/style.css">

	<link rel="stylesheet" href="css/detail.css">
</head>

<body>


	<div id="site-content">
		<header class="smaller normal regular">
			<div id="content">
				<div id="leftside">
					<ul class="primary">
						<li class="logo"><a href="index.php"><img src="img/logo.png"></a></li>
						<li class="menulist"><a class="menu" href="/discover">Discover</a></li>
						<li class="menulist"><a href="/discover" class="menu">Movies</a></li>
						<li class="menulist"><a href="/discover" class="menu">TV shows</a></li>
						<li class="menulist"><a href="/discover" class="menu">People </a></li>
					</ul>
				</div>


				<div class="search_bar">
					<section class="search">
						<div class="sub_media">
							<form id="search_form" action="/search" method="get" accept-charset="utf-8">
								<input dir="auto" id="search_v4" name="query" type="text" tabindex="0" autocorrect="off" autofill="off" autocomplete="off" spellcheck="false" placeholder="Search for a movie, tv show, person..." value="">
							</form>
						</div>
					</section>
				</div>
		</header>

	</div>

	<script src="js/detail.js"></script>
	<div id="movie_data">

	</div>
	<!-- <div id="media_v4" class="media movie_v4 header_large">
		
		<div class="column_wrapper">

			<div>
				<div class="white_column">

					<div>
						<section class="panel top_billed scroller">
							<h3 dir="auto">Top Billed Cast</h3>


							<ol class="people scroller">

								<li class="card">
									<a href="/person/1515478-mena-massoud">


										<img class="profile fade lazyautosizes lazyloaded" data-sizes="auto" data-src="https://image.tmdb.org/t/p/w138_and_h175_face/yeaEd4P4kNlRkDqzunsQeh24rQm.jpg" data-srcset="https://image.tmdb.org/t/p/w138_and_h175_face/yeaEd4P4kNlRkDqzunsQeh24rQm.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/yeaEd4P4kNlRkDqzunsQeh24rQm.jpg 2x" alt="Mena Massoud" sizes="138px" srcset="https://image.tmdb.org/t/p/w138_and_h175_face/yeaEd4P4kNlRkDqzunsQeh24rQm.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/yeaEd4P4kNlRkDqzunsQeh24rQm.jpg 2x" src="https://image.tmdb.org/t/p/w138_and_h175_face/yeaEd4P4kNlRkDqzunsQeh24rQm.jpg">



									</a>

									<p><a href="/person/1515478-mena-massoud">Mena Massoud</a></p>
									<p class="character">Aladdin</p>
								</li>

								<li class="card">
									<a href="/person/240724-naomi-scott">


										<img class="profile fade lazyautosizes lazyloaded" data-sizes="auto" data-src="https://image.tmdb.org/t/p/w138_and_h175_face/d140yTWCle6rYUGE9GIVZVPaPng.jpg" data-srcset="https://image.tmdb.org/t/p/w138_and_h175_face/d140yTWCle6rYUGE9GIVZVPaPng.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/d140yTWCle6rYUGE9GIVZVPaPng.jpg 2x" alt="Naomi Scott" sizes="138px" srcset="https://image.tmdb.org/t/p/w138_and_h175_face/d140yTWCle6rYUGE9GIVZVPaPng.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/d140yTWCle6rYUGE9GIVZVPaPng.jpg 2x" src="https://image.tmdb.org/t/p/w138_and_h175_face/d140yTWCle6rYUGE9GIVZVPaPng.jpg">



									</a>

									<p><a href="/person/240724-naomi-scott">Naomi Scott</a></p>
									<p class="character">Jasmine</p>
								</li>

								<li class="card">
									<a href="/person/2888-will-smith">


										<img class="profile fade lazyautosizes lazyloaded" data-sizes="auto" data-src="https://image.tmdb.org/t/p/w138_and_h175_face/eze9FO9VuryXLP0aF2cRqPCcibN.jpg" data-srcset="https://image.tmdb.org/t/p/w138_and_h175_face/eze9FO9VuryXLP0aF2cRqPCcibN.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/eze9FO9VuryXLP0aF2cRqPCcibN.jpg 2x" alt="Will Smith" sizes="138px" srcset="https://image.tmdb.org/t/p/w138_and_h175_face/eze9FO9VuryXLP0aF2cRqPCcibN.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/eze9FO9VuryXLP0aF2cRqPCcibN.jpg 2x" src="https://image.tmdb.org/t/p/w138_and_h175_face/eze9FO9VuryXLP0aF2cRqPCcibN.jpg">



									</a>

									<p><a href="/person/2888-will-smith">Will Smith</a></p>
									<p class="character">Genie</p>
								</li>

								<li class="card">
									<a href="/person/935235-marwan-kenzari">


										<img class="profile fade lazyautosizes lazyloaded" data-sizes="auto" data-src="https://image.tmdb.org/t/p/w138_and_h175_face/k0qx65csI86rAFBR4Sal7phY3Vl.jpg" data-srcset="https://image.tmdb.org/t/p/w138_and_h175_face/k0qx65csI86rAFBR4Sal7phY3Vl.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/k0qx65csI86rAFBR4Sal7phY3Vl.jpg 2x" alt="Marwan Kenzari" sizes="138px" srcset="https://image.tmdb.org/t/p/w138_and_h175_face/k0qx65csI86rAFBR4Sal7phY3Vl.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/k0qx65csI86rAFBR4Sal7phY3Vl.jpg 2x" src="https://image.tmdb.org/t/p/w138_and_h175_face/k0qx65csI86rAFBR4Sal7phY3Vl.jpg">



									</a>

									<p><a href="/person/935235-marwan-kenzari">Marwan Kenzari</a></p>
									<p class="character">Jafar</p>
								</li>

								<li class="card">
									<a href="/person/103330-navid-negahban">


										<img class="profile fade lazyautosizes lazyloaded" data-sizes="auto" data-src="https://image.tmdb.org/t/p/w138_and_h175_face/cPsYncbHK7J76Sm4bc1rtgRh5qf.jpg" data-srcset="https://image.tmdb.org/t/p/w138_and_h175_face/cPsYncbHK7J76Sm4bc1rtgRh5qf.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/cPsYncbHK7J76Sm4bc1rtgRh5qf.jpg 2x" alt="Navid Negahban" sizes="138px" srcset="https://image.tmdb.org/t/p/w138_and_h175_face/cPsYncbHK7J76Sm4bc1rtgRh5qf.jpg 1x, https://image.tmdb.org/t/p/w276_and_h350_face/cPsYncbHK7J76Sm4bc1rtgRh5qf.jpg 2x" src="https://image.tmdb.org/t/p/w138_and_h175_face/cPsYncbHK7J76Sm4bc1rtgRh5qf.jpg">



									</a>

									<p><a href="/person/103330-navid-negahban">Navid Negahban</a></p>
									<p class="character">The Sultan</p>
								</li>


							</ol>




							<p class="new_button"><a class="" href="/movie/420817-aladdin/cast">Full Cast &amp; Crew</a></p>


						</section>

						<section class="panel media_panel social_panel">
							<section class="review">
								<div class="menu">
									<h3 dir="auto">Social</h3>
									<ul>
										<li class="active" dir="auto"><a id="reviews" class="media_panel" href="#">Reviews <span>3</span></a></li>
										<li class="" dir="auto"><a id="discussions" class="media_panel" href="#">Discussions <span>9</span></a></li>
									</ul>
								</div>

								<div class="content">

									<div class="original_content">
										<div class="review_container three">
											<div class="content three">

												<div class="inner_content">
													<div class="content">
														<div class="inner_content">
															<div class="card">
																<div class="grouped">
																	<div class="avatar">
																		<a href="/u/Ruuz">

																			<img class="avatar lazyloaded" data-src="https://image.tmdb.org/t/p/w64_and_h64_face/xUObnJSvHrFPsIpoDmb1jiQZLq7.jpg" data-srcset="https://image.tmdb.org/t/p/w64_and_h64_face/xUObnJSvHrFPsIpoDmb1jiQZLq7.jpg 1x, https://image.tmdb.org/t/p/w128_and_h128_face/xUObnJSvHrFPsIpoDmb1jiQZLq7.jpg 2x" alt="Gimly" srcset="https://image.tmdb.org/t/p/w64_and_h64_face/xUObnJSvHrFPsIpoDmb1jiQZLq7.jpg 1x, https://image.tmdb.org/t/p/w128_and_h128_face/xUObnJSvHrFPsIpoDmb1jiQZLq7.jpg 2x" src="https://image.tmdb.org/t/p/w64_and_h64_face/xUObnJSvHrFPsIpoDmb1jiQZLq7.jpg">

																		</a>
																	</div>

																	<div class="info">


																		<div class="rating_wrapper">
																			<h3><a href="/review/5d6e3f6aa284eb473233f9de">A review by Gimly</a></h3>
																			<div class="rounded rating"><span class="glyphicons glyphicons-star x1"></span> 4.0</div>
																		</div>

																		<h5>Written by <a href="/u/Ruuz">Gimly</a> on September 3, 2019</h5>
																	</div>
																</div>

																<div class="teaser">

																	<p>While I am fully prepared to admit that I hated this slightly less than I expected to, I also officially give up on Guy Ritchie. Disney's original <em>Aladdin</em> is not one of my favourite Disney flicks, but I do like it. And although I'm sure there are people out there who will appreciate this live action do-over more than me, I do find it difficult to believe anyone would think this one is the better of the two versions.</p>

																	<p><em>Final rating:★★ - Had some things that appeal to me, but a poor finished product.</em></p>


																</div>
															</div>
														</div>
													</div>

													<p class="new_button"><a href="/movie/420817-aladdin/reviews">Read All Reviews</a></p>
												</div>

											</div>
										</div>
									</div>

								</div>
							</section>
						</section>

						<section class="panel media_panel media scroller">

							<div class="menu">
								<h3 dir="auto">Media</h3>
								<ul>
									<li class="active" dir="auto"><a id="popular" class="media_panel" href="#">Most Popular</a></li>
									<li dir="auto"><a id="videos" class="media_panel" href="#">Videos <span>3</span></a></li>
									<li dir="auto"><a id="backdrops" class="media_panel" href="#">Backdrops <span>23</span></a></li>
									<li dir="auto"><a id="posters" class="media_panel" href="#">Posters <span>119</span></a></li>
									<li class="view_all"></li>
								</ul>
							</div>
							<div class="content h_scroller">
								<div class="original_content h_scroller">

									<div class="video card no_border">
										<div class="wrapper" style="background-image: url('https://i.ytimg.com/vi/9g5knnlF7Zo/hqdefault.jpg');">
											<a class="no_click play_trailer" href="/video/play?key=9g5knnlF7Zo" data-site="YouTube" data-id="9g5knnlF7Zo" data-title="Disney's Aladdin Teaser Trailer - In Theaters May 24th, 2019">
												<div class="play_background"><span class="glyphicons glyphicons-play-button"></span></div>
											</a>
										</div>
									</div>





									<div class="backdrop">


										<img class="backdrop fade lazyautosizes lazyloaded" data-sizes="auto" data-src="https://image.tmdb.org/t/p/w533_and_h300_bestv2/rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg" data-srcset="https://image.tmdb.org/t/p/w533_and_h300_bestv2/rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg 1x, https://image.tmdb.org/t/p/w1066_and_h600_bestv2/rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg 2x" alt="Aladdin" sizes="533px" srcset="https://image.tmdb.org/t/p/w533_and_h300_bestv2/rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg 1x, https://image.tmdb.org/t/p/w1066_and_h600_bestv2/rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg 2x" src="https://image.tmdb.org/t/p/w533_and_h300_bestv2/rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg">



									</div>





									<div class="poster">


										<img class="poster" src="https://image.tmdb.org/t/p/w220_and_h330_face/3iYQTLGoy7QnjcUYRJy4YrAgGvp.jpg" srcset="https://image.tmdb.org/t/p/w220_and_h330_face/3iYQTLGoy7QnjcUYRJy4YrAgGvp.jpg 1x, https://image.tmdb.org/t/p/w440_and_h660_face/3iYQTLGoy7QnjcUYRJy4YrAgGvp.jpg 2x" alt="Aladdin">



									</div>




								</div>
							</div>

						</section>




						<section class="panel recommendations scroller">
							<div id="recommendation_waypoint"></div>
							<script>
								var recommendation_waypoint_check = false;
								new Waypoint({
									element: document.getElementById('recommendation_waypoint'),
									handler: function(direction) {
										if (direction == 'down' && !recommendation_waypoint_check) {
											$.ajax({
												url: '/movie/420817-aladdin/remote/recommendations?version=1&translate=false&language=en-US',
												type: 'GET',
												headers: {
													'Accept-Language': 'en-US',
													'Content-Type': 'text/html;charset=utf-8'
												}
											}).done(function(response) {
												recommendation_waypoint_check = true;

												$('#recommendation_waypoint').html(response).hide().fadeIn(1000);
											});
										}
									},
									offset: '100%'
								});
							</script>
						</section>

					</div>

				</div>
			</div>

			<div class="grey_column">
				<div>

					<section class="split_column">
						<div>
							<div class="column no_bottom_pad">
								<section class="facts left_column">
									<div class="social_links">

										<div>
											<a class="social_link" title="Visit Facebook" href="https://www.facebook.com/DisneyAladdin" target="_blank" rel="noopener" data-role="tooltip"><span class="social social-facebook"></span></a>
										</div>


										<div>
											<a class="social_link" title="Visit Twitter" href="https://twitter.com/disneyaladdin" target="_blank" rel="noopener" data-role="tooltip"><span class="social social-twitter"></span></a>
										</div>


										<div>
											<a class="social_link" title="Visit Instagram" href="https://instagram.com/disneyaladdin/" target="_blank" rel="noopener" data-role="tooltip"><span class="social social-instagram"></span></a>
										</div>


										<div class="homepage">
											<a class="social_link" title="Visit Homepage" href="https://movies.disney.com/aladdin-2019" target="_blank" rel="noopener" data-role="tooltip"><span class="glyphicons glyphicons-link"></span></a>
										</div>

									</div>

									<h4><bdi>Facts</bdi></h4>

									<p><strong><bdi>Status</bdi></strong> Released</p>


									<p class="no_bottom_pad"><strong>Release Information</strong></p>
									<ul class="releases" data-role="tooltip">

										<li>
											<img width="24" height="24" src="https://www.themoviedb.org/assets/2/flags_v2/24/US-e86237650fc6e4b6f2255f3266bab2099e441962200f2da54d1aa34a3205ee86.png" srcset="https://www.themoviedb.org/assets/2/flags_v2/24/US-e86237650fc6e4b6f2255f3266bab2099e441962200f2da54d1aa34a3205ee86.png 1x, https://www.themoviedb.org/assets/2/flags_v2/48/US-fc54af6e5c8237200d49fd6a49061fffeb8a7217bb9000acd1c02039b65b22ba.png 2x, https://www.themoviedb.org/assets/2/flags_v2/64/US-35bf08cd02d9c5ebef38cbfbd47c1c06f4d06203f8f0e5dce2d20c6cfb0281a7.png 3x">
											May 24, 2019<br>
											<div class="certification">
												<div><span element="58f9932392514158c6004450">PG</span></div> Theatrical
											</div>
											<div id="58f9932392514158c6004450" class="tooltip certification_info hide">
												<div class="certification_tooltip">
													<h3>Meaning</h3>
													<p>Some material may not be suitable for children under 10. These films may contain some mild language, crude/suggestive humor, scary moments and/or violence. No drug content is present. There are a few exceptions to this rule. A few racial insults may also be heard.</p>
												</div>
											</div>
										</li>

										<li>
											<img width="24" height="24" src="https://www.themoviedb.org/assets/2/flags_v2/24/US-e86237650fc6e4b6f2255f3266bab2099e441962200f2da54d1aa34a3205ee86.png" srcset="https://www.themoviedb.org/assets/2/flags_v2/24/US-e86237650fc6e4b6f2255f3266bab2099e441962200f2da54d1aa34a3205ee86.png 1x, https://www.themoviedb.org/assets/2/flags_v2/48/US-fc54af6e5c8237200d49fd6a49061fffeb8a7217bb9000acd1c02039b65b22ba.png 2x, https://www.themoviedb.org/assets/2/flags_v2/64/US-35bf08cd02d9c5ebef38cbfbd47c1c06f4d06203f8f0e5dce2d20c6cfb0281a7.png 3x">
											August 27, 2019<br>
											<div class="certification">
												<div><span element="5d51fba5b686b923f799028d">PG</span></div> Digital
											</div>
											<div id="5d51fba5b686b923f799028d" class="tooltip certification_info hide">
												<div class="certification_tooltip">
													<h3>Meaning</h3>
													<p>Some material may not be suitable for children under 10. These films may contain some mild language, crude/suggestive humor, scary moments and/or violence. No drug content is present. There are a few exceptions to this rule. A few racial insults may also be heard.</p>
												</div>
											</div>
										</li>

										<li>
											<img width="24" height="24" src="https://www.themoviedb.org/assets/2/flags_v2/24/US-e86237650fc6e4b6f2255f3266bab2099e441962200f2da54d1aa34a3205ee86.png" srcset="https://www.themoviedb.org/assets/2/flags_v2/24/US-e86237650fc6e4b6f2255f3266bab2099e441962200f2da54d1aa34a3205ee86.png 1x, https://www.themoviedb.org/assets/2/flags_v2/48/US-fc54af6e5c8237200d49fd6a49061fffeb8a7217bb9000acd1c02039b65b22ba.png 2x, https://www.themoviedb.org/assets/2/flags_v2/64/US-35bf08cd02d9c5ebef38cbfbd47c1c06f4d06203f8f0e5dce2d20c6cfb0281a7.png 3x">
											September 10, 2019<br>
											<div class="certification">
												<div><span element="5d51fbbb17b5ef0016dce1ff">PG</span></div> Physical
											</div>
											<div id="5d51fbbb17b5ef0016dce1ff" class="tooltip certification_info hide">
												<div class="certification_tooltip">
													<h3>Meaning</h3>
													<p>Some material may not be suitable for children under 10. These films may contain some mild language, crude/suggestive humor, scary moments and/or violence. No drug content is present. There are a few exceptions to this rule. A few racial insults may also be heard.</p>
												</div>
											</div>
										</li>

									</ul>


									<p><strong><bdi>Original Language</bdi></strong> English</p>
									<p><strong><bdi>Runtime</bdi></strong> 2h 8m</p>
									<p><strong><bdi>Budget</bdi></strong> $183,000,000.00</p>
									<p><strong><bdi>Revenue</bdi></strong> $1,047,612,394.00</p>
								</section>

								<section class="genres right_column">
									<h4><bdi>Genres</bdi></h4>

									<ul>

										<li><a href="/genre/12-adventure/movie">Adventure</a></li>

										<li><a href="/genre/14-fantasy/movie">Fantasy</a></li>

										<li><a href="/genre/10749-romance/movie">Romance</a></li>

										<li><a href="/genre/35-comedy/movie">Comedy</a></li>

										<li><a href="/genre/10751-family/movie">Family</a></li>

									</ul>

								</section>

								<section class="keywords right_column">
									<h4><bdi>Keywords</bdi></h4>

									<ul>

										<li><a href="/keyword/2348-hustler/movie">hustler</a></li>

										<li><a href="/keyword/4344-musical/movie">musical</a></li>

										<li><a href="/keyword/4892-sultan/movie">sultan</a></li>

										<li><a href="/keyword/4895-flying-carpet/movie">flying carpet</a></li>

										<li><a href="/keyword/5626-rags-to-riches/movie">rags to riches</a></li>

										<li><a href="/keyword/15149-monkey/movie">monkey</a></li>

										<li><a href="/keyword/157303-first-love/movie">first love</a></li>

										<li><a href="/keyword/185343-based-on-myths-legends-or-folklore/movie">based on myths, legends or folklore</a></li>

										<li><a href="/keyword/190536-genie/movie">genie</a></li>

										<li><a href="/keyword/191012-arabian-nights/movie">arabian nights</a></li>

										<li><a href="/keyword/245230-live-action-remake/movie">live action remake</a></li>

									</ul>

								</section>


							</div>
						</div>

						<div>
							<section class="content_score">
								<h4 dir="auto">Content Score</h4>
								<div class="content_score">
									<div class="false" style="width: 100%;">
										<p>100</p>
									</div>
								</div>
								<p dir="auto">Yes! Looking good!</p>
							</section>

							<section class="leaderboard">
								<h4>Top Contributors</h4>

								<div class="leaders">


									<div class="edit_leader">
										<div class="avatar">
											<a href="/u/lineker">

												<img class="avatar lazyload fade" data-src="https://image.tmdb.org/t/p/w45_and_h45_face/e4HKlEFR9ytqnajSbAuMmRAXGyq.jpg" data-srcset="https://image.tmdb.org/t/p/w45_and_h45_face/e4HKlEFR9ytqnajSbAuMmRAXGyq.jpg 1x, https://image.tmdb.org/t/p/w90_and_h90_face/e4HKlEFR9ytqnajSbAuMmRAXGyq.jpg 2x" alt="lineker">

											</a>
										</div>
										<div class="info">
											<p class="edit_count">53</p>
											<p><a href="/u/lineker">lineker</a></p>
										</div>
									</div>

									<div class="edit_leader">
										<div class="avatar">
											<a href="/u/nextlooper42">

												<img class="avatar lazyload fade" data-src="https://image.tmdb.org/t/p/w45_and_h45_face/oczVBnMc7b4NbgEHWntWUoYka3o.jpg" data-srcset="https://image.tmdb.org/t/p/w45_and_h45_face/oczVBnMc7b4NbgEHWntWUoYka3o.jpg 1x, https://image.tmdb.org/t/p/w90_and_h90_face/oczVBnMc7b4NbgEHWntWUoYka3o.jpg 2x" alt="nextlooper42">

											</a>
										</div>
										<div class="info">
											<p class="edit_count">37</p>
											<p><a href="/u/nextlooper42">nextlooper42</a></p>
										</div>
									</div>

									<div class="edit_leader">
										<div class="avatar">
											<a href="/u/topkek327">

												<img class="avatar lazyload fade" data-src="https://image.tmdb.org/t/p/w45_and_h45_face/cNDCv5yGLucVYgpwWXOWEIE3KaH.jpg" data-srcset="https://image.tmdb.org/t/p/w45_and_h45_face/cNDCv5yGLucVYgpwWXOWEIE3KaH.jpg 1x, https://image.tmdb.org/t/p/w90_and_h90_face/cNDCv5yGLucVYgpwWXOWEIE3KaH.jpg 2x" alt="TopKek">

											</a>
										</div>
										<div class="info">
											<p class="edit_count">36</p>
											<p><a href="/u/topkek327">TopKek</a></p>
										</div>
									</div>

									<div class="edit_leader">
										<div class="avatar">
											<a href="/u/WardenclyffeTower">

												<img class="avatar lazyload fade" data-src="https://image.tmdb.org/t/p/w45_and_h45_face/784bIArIyDBskvnyDpB5sBAmYto.jpg" data-srcset="https://image.tmdb.org/t/p/w45_and_h45_face/784bIArIyDBskvnyDpB5sBAmYto.jpg 1x, https://image.tmdb.org/t/p/w90_and_h90_face/784bIArIyDBskvnyDpB5sBAmYto.jpg 2x" alt="Space Junk">

											</a>
										</div>
										<div class="info">
											<p class="edit_count">36</p>
											<p><a href="/u/WardenclyffeTower">Space Junk</a></p>
										</div>
									</div>


									<p><a href="/movie/420817-aladdin/changes"><span class="glyphicons glyphicons-chevron-right x1"></span> View Edit History</a></p>

								</div>
							</section>

							<section class="popularity_trend">
								<h4 dir="auto">Popularity Trend</h4>
								<div id="popularity_waypoint" class="popularity">
									<div id="popularity_chart"></div>
								</div>
							</section>
						</div>


						<div class="">
							<p class="rounded new_button pad"><a class="" href="/login"><span class="glyphicons glyphicons-lock x1"></span> Login to edit</a></p>
						</div>



						<div class="keyboard_shortcut_text">
							<p><a id="keyboard_shortcuts" class="no_click" href="#">Keyboard Shortcuts</a></p>
						</div>

					</section>

				</div>
			</div>

		</div>

	</div> -->
</body>

</html>