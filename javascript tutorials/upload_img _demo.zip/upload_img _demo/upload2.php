<?php
$path = "uploads/";
$extension = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
$name = $_POST['nameoffile'];
$nameoffile= $_FILES['file']['filename'] = $name;
$file_name = $path . basename($nameoffile.'.'.$extension); 
if($extension   =='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='gif'){
if (move_uploaded_file($_FILES['file']['tmp_name'], $file_name)) {
    echo  'Sucessfully uploaded file..';
} else {
    print "Upload failed!";
}
}
else{
    echo 'please upload only img';
}
?>
