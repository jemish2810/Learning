<html>
<head>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
    <script src="//oss.maxcdn.com/jquery.form/3.50/jquery.form.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <br />
        <div class="panel panel-default">
            <div class="panel-body">
                <form id="uploadImage" action="upload2.php" method="post">
                    <div class="form-group">
                        <label>File Upload</label>
                        <input type="file" name="uploadFile" id="uploadFile"  />
                    </div>
                    <div class="form-group">
                        <input type="submit" id="uploadSubmit" value="Upload" class="btn btn-info" />
                    </div>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <div id="targetLayer" style="display:none;"></div>
                </form>
                <div id="loader-icon" style="display:none;"><img src="LoaderIcon.gif" /></div>
            </div>
        </div>
</body>
<script>
    $(document).ready(function() {
        $('#uploadImage').submit(function(event) {
            if ($('#uploadFile').val()) {
                $('#loader-icon').show();
                $('#targetLayer').hide();
                $(this).ajaxSubmit({
                    target: '#targetLayer',
                    beforeSubmit: function() {
                        $('.progress-bar').width('0%');
                    },
                    uploadProgress: function(event, position, total, percentageComplete) {
                     
                       $('.progress-bar').animate({
                            width: percentageComplete + '%'
                        }, {
                            duration: 1000     
                        });
                    },
                    success: function() {
                        $('#loader-icon').hide();
                        $('#targetLayer').show();
                    },
                    resetForm: true
                });
            }
            return false;
        });
    });
</script>

</html>
