 import React from 'react'
 import styles from "./index.scss"

class AlbumComponent extends React.Component{
  constructor(props){
    super(props)
    this.state ={
      isLoading: false,
      errorMsg: "",
      successMsg: "",
      isRender:false,
      photos:[],
      isPlay: false,
    }
  }

  componentDidMount() {
    this.setState({
      isRender:true
    })
  }

  onClickEvent = () =>{

  }
  renderAlbumComponent = () => {
    return (
         <div className={styles.ff_album_card + " container-flu"}>
          <div className="row justify-content-center">
          <div div className = "col-lg-8" >
            <div>
                <div classaName={styles.ff_media}><img src="holder.js/100px180"/></div>
                <div className={styles.ff_card_des+"card-body" }>
                  <div className="card-title">Title</div>
                  <div className="card-title">price</div>
                  <div className="card-title">description</div>
                </div>
              </div>
            </div>
            </div>
         </div>
    )
  }

  render(){
    return(
    <div className={styles.ff_Album_detail}>
       <div className={`${styles.ff_box} ${styles.ff_b}`}>
          <div className={styles.ff_order_details}>
            <div className={styles.ff_header}>
              <div>
                <label>Order: </label>
              </div>
            </div>
            <div className={styles.ff_other_info}>
              <p>
                <strong>Title: </strong> 
              </p>
              <p>
                <strong>Price: </strong> 
              </p>
              <p>
                <strong>Description: </strong> 
              </p>
            </div>
          </div>
        </div>
      </div>
  
    )

}
}
export default AlbumComponent
 

  