import React, { Component } from 'react'
import Login from './login'

 class Auth extends Component {
    render() {
        return (
            <div>
                <Login/>
            </div>
        )
    }
}
export default Auth;
