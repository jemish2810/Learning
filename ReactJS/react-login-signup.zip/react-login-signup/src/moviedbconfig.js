export const USER_SERVER ="/api/users";

export const api_key = "38252124dbbb11a893376bd6da75d318";
export const url = "https://api.themoviedb.org/3/";
export const imageurl = "https: //image.tmdb.org/t/p/w185_and_h278_bestv2";
