import React, { useState, useEffect } from 'react';
import {
  BrowserRouter,
  Switch,
  Router, Route,
  NavLink
} from 'react-router-dom';
import TopBar from './components/TopBar';
import Login from './Login';
import Home from './Home';
 

 class App extends React.Component {
  render() {
    return (
      <div>
        <TopBar/>
         <Router>
        <div className="App">
            <Switch>
             {/* <Route exact path='/' component={Home}/> */}
             {/* <Route path="/login" component={Login} /> */}
            </Switch>
        </div>  
       
        </Router>
      </div>
    )
  }
}

export default App
 