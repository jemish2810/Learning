const istate = {
    name:'jemish',
    login:true,
    id:'',
    title:''
}
 const reducer = (state = istate, action) => {
    console.log('this is action ',action)
    if (action.type === 'CHANGE_NAME'){
        return{
            ...state,
            name:action.data
        }
    }
    else if(action.type === 'THUNKCHANGE') {
        return {
            ...state,
            title: action.data
        }
    }
    else{
        return state
    }
}
export default reducer