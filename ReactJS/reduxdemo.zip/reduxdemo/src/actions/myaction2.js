// action creator or redux thunk 

export const anotherChange = () => {
    return (dispatch)=>{
        fetch('https://jsonplaceholder.typicode.com/todos')
        .then(respo=>respo.json())
        .then(result=>{
            dispatch({type:'THUNKCHANGE',data:result[0].title})
        })
    }
    // or
// async syntax
    // return async (dispatch)=>{
    //     const data = await fetch('https://jsonplaceholder.typicode.com/todos')
    //     const respo= await data.json()
    //         dispatch({type:'THUNKCHANGE',data:respo[0].title})
    // }
}
export default anotherChange