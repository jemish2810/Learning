// action creator or redux thunk 
export const  anotherName =(name)=>{
    return {
        type: 'CHANGE_NAME',
        data: name
    }
}
export default anotherName
