import React from 'react';
import { connect } from 'react-redux'
import { anotherName} from './actions/myaction'
import { anotherChange} from './actions/myaction2'

function App(props) {
  console.log('app component',props)
  return (
    <div className="App">
            <div className="container">
               <h4>App Coomponent </h4>                 
               <h4>Data </h4>                 
               <h5>Name  :{props.myname }</h5>
               <h5>Thunk title :{props.title }</h5>
               <button onClick={()=>{props.changeData('Changed this data')}}>change name</button>
               <button onClick={()=>{props.thunkChange()}}>Thunk change</button>
            </div>
    </div>
  );
}
//get state data from reducer
const mapStateToProps = (state) =>{
  return{
    myname:state.name,
    islogin:state.login,
    title:state.title
  }
}

// update 
const mapDispatchToProps = (dispatch) => {
  return {
      changeData:(name) =>{dispatch(anotherName(name))},
      thunkChange:() =>{dispatch(anotherChange())},
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
// if any component want to change data only than write null in first argument of connect method 
// export default connect(null, mapDispatchToProps)(App);
