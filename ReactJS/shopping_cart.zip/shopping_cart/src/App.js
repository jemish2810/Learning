import React, { Component } from 'react'
import axios from "axios";
import Header from "./components/NavbarComponent/Header"
import Products from "./components/Products/Products"
class App extends Component {
  constructor() {
    super()
    this.state = {
      products: [],
      cart: [],
      totalItems: 0,
      totalAmount: 0,
      cartBounce: false,
      quantity: 1,
      // test:5
    };
    this.handleAddToCart = this.handleAddToCart.bind(this);
    this.sumTotalItems = this.sumTotalItems.bind(this);
    this.sumTotalAmount = this.sumTotalAmount.bind(this);
    this.checkProduct = this.checkProduct.bind(this);
    this.handleRemoveProduct = this.handleRemoveProduct.bind(this);
  }
  componentDidMount() {
    this.getProducts();
    // setInterval(() => {
    //   this.setState({test:5})
    // }, 2000);
  }
  
   getProducts() {
    //  const {products} = this.state
    // let url = "https://my-json-server.typicode.com/jemish28/dummyproducts/products";
    let url = "https://fakestoreapi.com/products";
    axios.get(url).then(response => {
      this.setState({
        products:response.data
      });
    });
    
  }

   // Add to Cart
  handleAddToCart(selectedProducts) {
    console.log("my orderd product ::",selectedProducts)
    const{cart} = this.state
     let cartItem = cart;
    let productID = selectedProducts.id
    let productQty = selectedProducts.quantity
    if (this.checkProduct(productID)) {
      console.log("One more added ");
      let index = cartItem.findIndex(x => x.id === productID)
      cartItem[index].quantity =
        Number(cartItem[index].quantity) + Number(productQty)
      this.setState({
        cart: cartItem
      });
    } else {
      cartItem.push(selectedProducts);
    }
    this.setState({
      cart: cartItem,
      cartBounce: true
    });
    this.sumTotalItems(cart);
    this.sumTotalAmount(cart);
  }

   handleRemoveProduct(id, e) {
    let cart = this.state.cart;
    let index = cart.findIndex(x => x.id === id);
    cart.splice(index, 1);
    this.setState({
      cart: cart
    });
    this.sumTotalItems(this.state.cart);
    this.sumTotalAmount(this.state.cart);
    e.preventDefault();
  }
  checkProduct(productID) {
    let cart = this.state.cart;
    return cart.some( item => {
      return item.id === productID;
    });
  }
  sumTotalItems() {
    let total = 0;
    let cart = this.state.cart;
    total = cart.length;
    this.setState({
      totalItems: total
    });
  }
  sumTotalAmount() {
    let total = 0;
    let cart = this.state.cart;
    for (var i = 0; i < cart.length; i++) {
      total += cart[i].price * parseInt(cart[i].quantity);
    }
    this.setState({
      totalAmount: total
    });
  }

  render() {
    const{products}= this.state
    // console.log("Total Products : ", products)
    // console.log("******parent component render*******");
    
    return (
      <div>
        <Header 
          cartBounce={this.state.cartBounce}
          total={this.state.totalAmount}
          totalItems={this.state.totalItems}
          cartItems={this.state.cart}
          removeProduct={this.handleRemoveProduct}
          // test = {this.state.test}
        />
        { 
          products.length > 0 &&
            <Products
             products = {products}
             addToCart={this.handleAddToCart}
             productQuantity={this.state.quantity}
            //  test = {this.state.test}
           />
        }
 
      </div>
    )
  }
}

export default App
