import React, { Component } from "react";
import EmptyCart from "../empty/EmptyCart"
import CartScrollBar from "../Cart/CartScrollBar"
import "./navbar.css"

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showCart: false,
      cart: this.props.cartItems,
    };
    // console.log("header",this.props.cartItems);
    
  }
  handleCart = e => {
    e.preventDefault();
    this.setState({
      showCart: !this.state.showCart
    });
  }
    //  shouldComponentUpdate(nextProps, nextState) {
    //    return nextProps.cartItems == this.props.cartItems;
    //  }

  renderCartProduct = () => {
  const {cart} = this.state
  // console.log("My cart",cart)
  return cart.length > 0 ?(
    cart &&
    cart.map(product => {
      return (
        <div key={product.id}>
          <li className="cart-item" key={product.name}>
            <img className="product-image" src={product.image} />
            <div className="product-info">
                <p className="product-name">{product.name}</p>
                <p className="product-price">{product.price}</p>
            </div>
            <div className="product-total">
                <p className="quantity">
                {product.quantity} {product.quantity > 1 ? "Nos." : "No."}{" "}
                </p>
                <p className="amount">{product.quantity * product.price}</p>
            </div>
            <a  className = "product-remove"
            href = "#"
            onClick = {this.props.removeProduct.bind(this, product.id)} >
            </a>
         </li>
       </div>
      )
    })
  )
  : 
    <EmptyCart/>
  
}
  
  render() {
    // console.log("simple compoent render", this.props.test);
    
    return (
      <header>
        <div className="container">
             <div className="brand">
                 Shop
            </div>
          <div className="cart">
            <div className="cart-info">
              <table>
                <tbody>
                  <tr>
                    <td>No. of items</td>
                    <td>:</td>
                    <td>
                      <strong>{this.props.totalItems}</strong>
                    </td>
                  </tr>
                  <tr>
                    <td>Sub Total</td>
                    <td>:</td>
                    <td>
                      <strong>{this.props.total}</strong>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <a
              className="cart-icon"
              href="#"
              onClick={this.handleCart.bind(this)}
              
            >
              <img
                className={this.props.cartBounce ? "tada" : " "}
                src="https://res.cloudinary.com/sivadass/image/upload/v1493548928/icons/bag.png"
                alt="Cart"
              />
              {this.props.totalItems ? (
                <span className="cart-count">{this.props.totalItems}</span>
              ) : (
                ""
              )}
            </a>
            <div className={
                this.state.showCart ? "cart-preview active" : "cart-preview"
              }
            >
              <CartScrollBar>
                {
                    this.renderCartProduct()
                }
              </CartScrollBar>
            </div>
          </div>
        </div>
      </header>
    );
  }
}

export default Header;
