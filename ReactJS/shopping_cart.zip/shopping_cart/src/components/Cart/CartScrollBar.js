import React, { Component } from "react";

class CartScrollBar extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    console.log(this.props.children);
    
    return (
        <div>
            {this.props.children}
        </div>
    );
  }
}

export default CartScrollBar;
