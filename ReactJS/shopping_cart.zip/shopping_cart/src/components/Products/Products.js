import React, { PureComponent} from 'react'
import Product from "./Product"
import  './products.css'
class Products extends PureComponent {
    constructor(props) {  
    super(props);
    this.state = {
      productData: []
    };
  }
  componentDidMount(){
     this.setState({
        productData: this.props.products
     })

  }
  renderproduct = () => {
  const {productData} = this.state
  // console.log("Products Page :", productData)
// console.log("pure component render",this.props.test);

  return (
    productData &&
    productData.length > 0 &&
    productData.map(product => {
      return (
        <div key = {
          product.id
        } >
          <Product
            history={this.props.history}
            key={product.id}
            price={product.price}
            name={product.name}
            image={product.image}
            id={product.id}
            addToCart={this.props.addToCart}
            productQuantity={this.props.productQuantity}
            updateQuantity={this.props.updateQuantity}
          />
        </div>
      )
    })
  )
}
  render() {
    return (
    <div className = "products-wrapper ">
        {this.renderproduct()}
     </div>);
  }
}


export default Products
