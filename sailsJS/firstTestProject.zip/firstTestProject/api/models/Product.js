/**
 * Product.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {
    name:{
      type:'string',
      maxLength: 200,
      required: true,
    },
    category:{
      type: 'string',
      maxLength: 200,
      required: true,
    },
    price:{
      type:'number',
      required: true
    }
  },

};

