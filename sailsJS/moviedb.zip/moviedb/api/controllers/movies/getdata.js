module.exports = {
  friendlyName: 'Getdata',
  description: 'Getdata movies.',
  inputs: {

  },
  exits: {

  },

  fn: async function (inputs, exits) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        var json = JSON.parse(xhttp.responseText);
        var results = json.results;
        console.log(results);
      }
    };
    xhttp.open("get", "https://api.themoviedb.org/3/movie/popular?api_key=38252124dbbb11a893376bd6da75d318", true);
    xhttp.send();
  }
}
