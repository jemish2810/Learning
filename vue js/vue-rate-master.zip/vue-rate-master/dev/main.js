import Vue from 'vue'
import App from '@/App'

export default new Vue({
	el: '#app',
	template: '<App/>',
	components: { App }
})
