import Vue from 'vue'
import VueTimers from 'vue-timers'
 
Vue.use(VueTimers)