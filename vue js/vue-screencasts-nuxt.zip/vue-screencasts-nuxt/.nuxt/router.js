import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0206e816 = () => interopDefault(import('../pages/account.vue' /* webpackChunkName: "pages/account" */))
const _2ace8619 = () => interopDefault(import('../pages/account/index.vue' /* webpackChunkName: "pages/account/index" */))
const _b4b358fc = () => interopDefault(import('../pages/account/billing.vue' /* webpackChunkName: "pages/account/billing" */))
const _d83013da = () => interopDefault(import('../pages/account/edit.vue' /* webpackChunkName: "pages/account/edit" */))
const _4c433e8e = () => interopDefault(import('../pages/account/email-preferences.vue' /* webpackChunkName: "pages/account/email-preferences" */))
const _181074d4 = () => interopDefault(import('../pages/account/next-steps.vue' /* webpackChunkName: "pages/account/next-steps" */))
const _8e037f10 = () => interopDefault(import('../pages/admin.vue' /* webpackChunkName: "pages/admin" */))
const _68976c70 = () => interopDefault(import('../pages/admin/code-summary/index.vue' /* webpackChunkName: "pages/admin/code-summary/index" */))
const _ee35e338 = () => interopDefault(import('../pages/admin/courses/index.vue' /* webpackChunkName: "pages/admin/courses/index" */))
const _310a813e = () => interopDefault(import('../pages/admin/training-modules/index.vue' /* webpackChunkName: "pages/admin/training-modules/index" */))
const _782504f4 = () => interopDefault(import('../pages/admin/users/index.vue' /* webpackChunkName: "pages/admin/users/index" */))
const _4b3e567c = () => interopDefault(import('../pages/admin/videos/index.vue' /* webpackChunkName: "pages/admin/videos/index" */))
const _5a212eb2 = () => interopDefault(import('../pages/admin/courses/new.vue' /* webpackChunkName: "pages/admin/courses/new" */))
const _49f6f490 = () => interopDefault(import('../pages/admin/videos/new.vue' /* webpackChunkName: "pages/admin/videos/new" */))
const _1ef5cad8 = () => interopDefault(import('../pages/admin/code-summary/_id.vue' /* webpackChunkName: "pages/admin/code-summary/_id" */))
const _5fef5162 = () => interopDefault(import('../pages/admin/courses/_id/index.vue' /* webpackChunkName: "pages/admin/courses/_id/index" */))
const _514482a6 = () => interopDefault(import('../pages/admin/videos/_id/index.vue' /* webpackChunkName: "pages/admin/videos/_id/index" */))
const _7834261d = () => interopDefault(import('../pages/admin/courses/_id/edit.vue' /* webpackChunkName: "pages/admin/courses/_id/edit" */))
const _69f54a02 = () => interopDefault(import('../pages/admin/videos/_id/edit.vue' /* webpackChunkName: "pages/admin/videos/_id/edit" */))
const _93dca7e2 = () => interopDefault(import('../pages/auth.vue' /* webpackChunkName: "pages/auth" */))
const _c2542438 = () => interopDefault(import('../pages/courses/index.vue' /* webpackChunkName: "pages/courses/index" */))
const _bf4ca612 = () => interopDefault(import('../pages/order.vue' /* webpackChunkName: "pages/order" */))
const _5d226d7a = () => interopDefault(import('../pages/policies/index.vue' /* webpackChunkName: "pages/policies/index" */))
const _1ed73dd4 = () => interopDefault(import('../pages/pro.vue' /* webpackChunkName: "pages/pro" */))
const _d01fcdca = () => interopDefault(import('../pages/testimonials.vue' /* webpackChunkName: "pages/testimonials" */))
const _3df98c02 = () => interopDefault(import('../pages/videos.vue' /* webpackChunkName: "pages/videos" */))
const _463ed91f = () => interopDefault(import('../pages/policies/privacy-policy.vue' /* webpackChunkName: "pages/policies/privacy-policy" */))
const _3944bcfc = () => interopDefault(import('../pages/policies/terms-and-conditions.vue' /* webpackChunkName: "pages/policies/terms-and-conditions" */))
const _8be3cd68 = () => interopDefault(import('../pages/courses/_id.vue' /* webpackChunkName: "pages/courses/_id" */))
const _7054d3a3 = () => interopDefault(import('../pages/watch/_id.vue' /* webpackChunkName: "pages/watch/_id" */))
const _f0e2270a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/account",
    component: _0206e816,
    children: [{
      path: "",
      component: _2ace8619,
      name: "account"
    }, {
      path: "billing",
      component: _b4b358fc,
      name: "account-billing"
    }, {
      path: "edit",
      component: _d83013da,
      name: "account-edit"
    }, {
      path: "email-preferences",
      component: _4c433e8e,
      name: "account-email-preferences"
    }, {
      path: "next-steps",
      component: _181074d4,
      name: "account-next-steps"
    }]
  }, {
    path: "/admin",
    component: _8e037f10,
    name: "admin",
    children: [{
      path: "code-summary",
      component: _68976c70,
      name: "admin-code-summary"
    }, {
      path: "courses",
      component: _ee35e338,
      name: "admin-courses"
    }, {
      path: "training-modules",
      component: _310a813e,
      name: "admin-training-modules"
    }, {
      path: "users",
      component: _782504f4,
      name: "admin-users"
    }, {
      path: "videos",
      component: _4b3e567c,
      name: "admin-videos"
    }, {
      path: "courses/new",
      component: _5a212eb2,
      name: "admin-courses-new"
    }, {
      path: "videos/new",
      component: _49f6f490,
      name: "admin-videos-new"
    }, {
      path: "code-summary/:id?",
      component: _1ef5cad8,
      name: "admin-code-summary-id"
    }, {
      path: "courses/:id",
      component: _5fef5162,
      name: "admin-courses-id"
    }, {
      path: "videos/:id",
      component: _514482a6,
      name: "admin-videos-id"
    }, {
      path: "courses/:id/edit",
      component: _7834261d,
      name: "admin-courses-id-edit"
    }, {
      path: "videos/:id/edit",
      component: _69f54a02,
      name: "admin-videos-id-edit"
    }]
  }, {
    path: "/auth",
    component: _93dca7e2,
    name: "auth"
  }, {
    path: "/courses",
    component: _c2542438,
    name: "courses"
  }, {
    path: "/order",
    component: _bf4ca612,
    name: "order"
  }, {
    path: "/policies",
    component: _5d226d7a,
    name: "policies"
  }, {
    path: "/pro",
    component: _1ed73dd4,
    name: "pro"
  }, {
    path: "/testimonials",
    component: _d01fcdca,
    name: "testimonials"
  }, {
    path: "/videos",
    component: _3df98c02,
    name: "videos"
  }, {
    path: "/policies/privacy-policy",
    component: _463ed91f,
    name: "policies-privacy-policy"
  }, {
    path: "/policies/terms-and-conditions",
    component: _3944bcfc,
    name: "policies-terms-and-conditions"
  }, {
    path: "/courses/:id",
    component: _8be3cd68,
    name: "courses-id"
  }, {
    path: "/watch/:id?",
    component: _7054d3a3,
    name: "watch-id"
  }, {
    path: "/",
    component: _f0e2270a,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
