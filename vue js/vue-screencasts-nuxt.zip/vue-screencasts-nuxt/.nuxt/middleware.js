const middleware = {}

middleware['auth-admin'] = require('../middleware/auth-admin.js')
middleware['auth-admin'] = middleware['auth-admin'].default || middleware['auth-admin']

middleware['auth-guard'] = require('../middleware/auth-guard.js')
middleware['auth-guard'] = middleware['auth-guard'].default || middleware['auth-guard']

middleware['load-videos-and-courses'] = require('../middleware/load-videos-and-courses.js')
middleware['load-videos-and-courses'] = middleware['load-videos-and-courses'].default || middleware['load-videos-and-courses']

export default middleware
