import Vue from 'vue'
import Meta from 'vue-meta'
import ClientOnly from 'vue-client-only'
import NoSsr from 'vue-no-ssr'
import { createRouter } from './router.js'
import NuxtChild from './components/nuxt-child.js'
import NuxtError from './components/nuxt-error.vue'
import Nuxt from './components/nuxt.js'
import App from './App.js'
import { setContext, getLocation, getRouteData, normalizeError } from './utils'
import { createStore } from './store.js'

/* Plugins */

import nuxt_plugin_workbox_bb28a7c2 from 'nuxt_plugin_workbox_bb28a7c2' // Source: ./workbox.js (mode: 'client')
import nuxt_plugin_nuxticons_337c2136 from 'nuxt_plugin_nuxticons_337c2136' // Source: ./nuxt-icons.js (mode: 'all')
import nuxt_plugin_plugin_65f5c5e1 from 'nuxt_plugin_plugin_65f5c5e1' // Source: ./vuetify/plugin.js (mode: 'all')
import nuxt_plugin_vuecurrencyfilter_8f263228 from 'nuxt_plugin_vuecurrencyfilter_8f263228' // Source: ./vue-currency-filter.js (mode: 'all')
import nuxt_plugin_templatesplugin50b9ba20_2a856984 from 'nuxt_plugin_templatesplugin50b9ba20_2a856984' // Source: ./templates.plugin.50b9ba20.js (mode: 'all')
import nuxt_plugin_axios_de19c87a from 'nuxt_plugin_axios_de19c87a' // Source: ./axios.js (mode: 'all')
import nuxt_plugin_templatesplugin0308f318_46baeff4 from 'nuxt_plugin_templatesplugin0308f318_46baeff4' // Source: ./templates.plugin.0308f318.js (mode: 'client')
import nuxt_plugin_googleanalytics_55b65483 from 'nuxt_plugin_googleanalytics_55b65483' // Source: ./google-analytics.js (mode: 'client')
import nuxt_plugin_vuetifydatetimepicker_cdb158aa from 'nuxt_plugin_vuetifydatetimepicker_cdb158aa' // Source: ../plugins/vuetify-datetime-picker (mode: 'all')
import nuxt_plugin_vuetimer_73799188 from 'nuxt_plugin_vuetimer_73799188' // Source: ../plugins/vue-timer (mode: 'client')
import nuxt_plugin_vueshortkey_824caf0e from 'nuxt_plugin_vueshortkey_824caf0e' // Source: ../plugins/vue-shortkey.js (mode: 'client')
import nuxt_plugin_vue2filters_60d05d10 from 'nuxt_plugin_vue2filters_60d05d10' // Source: ../plugins/vue2-filters (mode: 'all')
import nuxt_plugin_plugin_1e990abf from 'nuxt_plugin_plugin_1e990abf' // Source: ./auth/plugin.js (mode: 'all')

// Component: <ClientOnly>
Vue.component(ClientOnly.name, ClientOnly)

// TODO: Remove in Nuxt 3: <NoSsr>
Vue.component(NoSsr.name, {
  ...NoSsr,
  render (h, ctx) {
    if (process.client && !NoSsr._warned) {
      NoSsr._warned = true

      console.warn('<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead')
    }
    return NoSsr.render(h, ctx)
  }
})

// Component: <NuxtChild>
Vue.component(NuxtChild.name, NuxtChild)
Vue.component('NChild', NuxtChild)

// Component NuxtLink is imported in server.js or client.js

// Component: <Nuxt>
Vue.component(Nuxt.name, Nuxt)

Vue.use(Meta, {"keyName":"head","attribute":"data-n-head","ssrAttribute":"data-n-head-ssr","tagIDKeyName":"hid"})

const defaultTransition = {"name":"page","mode":"out-in","appear":false,"appearClass":"appear","appearActiveClass":"appear-active","appearToClass":"appear-to"}

async function createApp(ssrContext, config = {}) {
  const router = await createRouter(ssrContext)

  const store = createStore(ssrContext)
  // Add this.$router into store actions/mutations
  store.$router = router

  // Fix SSR caveat https://github.com/nuxt/nuxt.js/issues/3757#issuecomment-414689141
  const registerModule = store.registerModule
  store.registerModule = (path, rawModule, options) => registerModule.call(store, path, rawModule, Object.assign({ preserveState: process.client }, options))

  // Create Root instance

  // here we inject the router and store to all child components,
  // making them available everywhere as `this.$router` and `this.$store`.
  const app = {
    head: {"title":"Vue Screencasts - Intermediate and Advanced Tutorials, Trainings, and Mentorship","meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1"},{"hid":"description","name":"description","content":"VueJS Screencasts for intermediate and advanced developers"},{"hid":"og-title","property":"og:title","content":"VueScreencasts - Intermediate and Advanced Tutorials, Trainings, and Mentorship"},{"hid":"og-site-name","property":"og:site_name","content":"VueScreencasts.com"},{"hid":"og-image","property":"og:image","content":"https:\u002F\u002Fvue-screencasts-uploads.s3-us-west-2.amazonaws.com\u002Fthumbnails\u002Flogo.png"},{"hid":"og-image-url","property":"og:image:url","content":"https:\u002F\u002Fvue-screencasts-uploads.s3-us-west-2.amazonaws.com\u002Fthumbnails\u002Flogo.png"},{"hid":"og-image-width","property":"og:image:width","content":1280},{"hid":"og-image-height","property":"og:image:height","content":720},{"hid":"og-image-type","property":"og:image:type","content":"image\u002Fjpeg"},{"hid":"twitter-card","property":"twitter:card"},{"hid":"twitter-site","property":"twitter:site","content":"VueScreencasts.com"},{"hid":"twitter-creator","property":"twitter:creator","content":"vuescreencasts"},{"hid":"twitter-img-src","property":"twitter:image","content":"https:\u002F\u002Fvue-screencasts-uploads.s3-us-west-2.amazonaws.com\u002Fthumbnails\u002Flogo.png"},{"hid":"twitter-title","property":"twitter:title","content":"VueScreencasts.com"},{"hid":"mobile-web-app-capable","name":"mobile-web-app-capable","content":"yes"},{"hid":"apple-mobile-web-app-title","name":"apple-mobile-web-app-title","content":"VueScreencasts.com"},{"hid":"author","name":"author","content":"jeffreybiles"},{"hid":"theme-color","name":"theme-color","content":"#fff"},{"hid":"og:type","name":"og:type","property":"og:type","content":"website"},{"hid":"og:description","name":"og:description","property":"og:description","content":"VueJS Screencasts for intermediate and advanced developers"}],"link":[{"rel":"icon","type":"image\u002Fx-icon","href":"\u002Ffavicon.ico"},{"rel":"stylesheet","type":"text\u002Fcss","href":"https:\u002F\u002Ffonts.googleapis.com\u002Fcss?family=Roboto:100,300,400,500,700,900&display=swap"},{"rel":"stylesheet","type":"text\u002Fcss","href":"https:\u002F\u002Fcdn.jsdelivr.net\u002Fnpm\u002F@mdi\u002Ffont@latest\u002Fcss\u002Fmaterialdesignicons.min.css"},{"rel":"manifest","href":"\u002F_nuxt\u002Fmanifest.b6fb1ad9.json"},{"rel":"shortcut icon","href":"\u002F_nuxt\u002Ficons\u002Ficon_64.5f6a36.png"},{"rel":"apple-touch-icon","href":"\u002F_nuxt\u002Ficons\u002Ficon_512.5f6a36.png","sizes":"512x512"}],"style":[],"script":[{"src":"https:\u002F\u002Fjs.stripe.com\u002Fv3\u002F","defer":true,"async":true}],"htmlAttrs":{"lang":"en"}},

    store,
    router,
    nuxt: {
      defaultTransition,
      transitions: [defaultTransition],
      setTransitions (transitions) {
        if (!Array.isArray(transitions)) {
          transitions = [transitions]
        }
        transitions = transitions.map((transition) => {
          if (!transition) {
            transition = defaultTransition
          } else if (typeof transition === 'string') {
            transition = Object.assign({}, defaultTransition, { name: transition })
          } else {
            transition = Object.assign({}, defaultTransition, transition)
          }
          return transition
        })
        this.$options.nuxt.transitions = transitions
        return transitions
      },

      err: null,
      dateErr: null,
      error (err) {
        err = err || null
        app.context._errored = Boolean(err)
        err = err ? normalizeError(err) : null
        let nuxt = app.nuxt // to work with @vue/composition-api, see https://github.com/nuxt/nuxt.js/issues/6517#issuecomment-573280207
        if (this) {
          nuxt = this.nuxt || this.$options.nuxt
        }
        nuxt.dateErr = Date.now()
        nuxt.err = err
        // Used in src/server.js
        if (ssrContext) {
          ssrContext.nuxt.error = err
        }
        return err
      }
    },
    ...App
  }

  // Make app available into store via this.app
  store.app = app

  const next = ssrContext ? ssrContext.next : location => app.router.push(location)
  // Resolve route
  let route
  if (ssrContext) {
    route = router.resolve(ssrContext.url).route
  } else {
    const path = getLocation(router.options.base, router.options.mode)
    route = router.resolve(path).route
  }

  // Set context to app.context
  await setContext(app, {
    store,
    route,
    next,
    error: app.nuxt.error.bind(app),
    payload: ssrContext ? ssrContext.payload : undefined,
    req: ssrContext ? ssrContext.req : undefined,
    res: ssrContext ? ssrContext.res : undefined,
    beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined,
    ssrContext
  })

  function inject(key, value) {
    if (!key) {
      throw new Error('inject(key, value) has no key provided')
    }
    if (value === undefined) {
      throw new Error(`inject('${key}', value) has no value provided`)
    }

    key = '$' + key
    // Add into app
    app[key] = value
    // Add into context
    if (!app.context[key]) {
      app.context[key] = value
    }

    // Add into store
    store[key] = app[key]

    // Check if plugin not already installed
    const installKey = '__nuxt_' + key + '_installed__'
    if (Vue[installKey]) {
      return
    }
    Vue[installKey] = true
    // Call Vue.use() to install the plugin into vm
    Vue.use(() => {
      if (!Object.prototype.hasOwnProperty.call(Vue.prototype, key)) {
        Object.defineProperty(Vue.prototype, key, {
          get () {
            return this.$root.$options[key]
          }
        })
      }
    })
  }

  // Inject runtime config as $config
  inject('config', config)

  if (process.client) {
    // Replace store state before plugins execution
    if (window.__NUXT__ && window.__NUXT__.state) {
      store.replaceState(window.__NUXT__.state)
    }
  }

  // Add enablePreview(previewData = {}) in context for plugins
  if (process.static && process.client) {
    app.context.enablePreview = function (previewData = {}) {
      app.previewData = Object.assign({}, previewData)
      inject('preview', previewData)
    }
  }
  // Plugin execution

  if (process.client && typeof nuxt_plugin_workbox_bb28a7c2 === 'function') {
    await nuxt_plugin_workbox_bb28a7c2(app.context, inject)
  }

  if (typeof nuxt_plugin_nuxticons_337c2136 === 'function') {
    await nuxt_plugin_nuxticons_337c2136(app.context, inject)
  }

  if (typeof nuxt_plugin_plugin_65f5c5e1 === 'function') {
    await nuxt_plugin_plugin_65f5c5e1(app.context, inject)
  }

  if (typeof nuxt_plugin_vuecurrencyfilter_8f263228 === 'function') {
    await nuxt_plugin_vuecurrencyfilter_8f263228(app.context, inject)
  }

  if (typeof nuxt_plugin_templatesplugin50b9ba20_2a856984 === 'function') {
    await nuxt_plugin_templatesplugin50b9ba20_2a856984(app.context, inject)
  }

  if (typeof nuxt_plugin_axios_de19c87a === 'function') {
    await nuxt_plugin_axios_de19c87a(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_templatesplugin0308f318_46baeff4 === 'function') {
    await nuxt_plugin_templatesplugin0308f318_46baeff4(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_googleanalytics_55b65483 === 'function') {
    await nuxt_plugin_googleanalytics_55b65483(app.context, inject)
  }

  if (typeof nuxt_plugin_vuetifydatetimepicker_cdb158aa === 'function') {
    await nuxt_plugin_vuetifydatetimepicker_cdb158aa(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_vuetimer_73799188 === 'function') {
    await nuxt_plugin_vuetimer_73799188(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_vueshortkey_824caf0e === 'function') {
    await nuxt_plugin_vueshortkey_824caf0e(app.context, inject)
  }

  if (typeof nuxt_plugin_vue2filters_60d05d10 === 'function') {
    await nuxt_plugin_vue2filters_60d05d10(app.context, inject)
  }

  if (typeof nuxt_plugin_plugin_1e990abf === 'function') {
    await nuxt_plugin_plugin_1e990abf(app.context, inject)
  }

  // Lock enablePreview in context
  if (process.static && process.client) {
    app.context.enablePreview = function () {
      console.warn('You cannot call enablePreview() outside a plugin.')
    }
  }

  // If server-side, wait for async component to be resolved first
  if (process.server && ssrContext && ssrContext.url) {
    await new Promise((resolve, reject) => {
      router.push(ssrContext.url, resolve, (err) => {
        // https://github.com/vuejs/vue-router/blob/v3.3.4/src/history/errors.js
        if (!err._isRouter) return reject(err)
        if (err.type !== 1 /* NavigationFailureType.redirected */) return resolve()

        // navigated to a different route in router guard
        const unregister = router.afterEach(async (to, from) => {
          ssrContext.url = to.fullPath
          app.context.route = await getRouteData(to)
          app.context.params = to.params || {}
          app.context.query = to.query || {}
          unregister()
          resolve()
        })
      })
    })
  }

  return {
    store,
    app,
    router
  }
}

export { createApp, NuxtError }
