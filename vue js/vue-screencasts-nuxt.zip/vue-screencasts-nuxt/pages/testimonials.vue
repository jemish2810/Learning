<template>
  <div>
    <SocialProofGrid />
  </div>
</template>

<script>
  import SocialProofGrid from '@/components/SocialProofGrid.vue';
  export default {
    components: {
      SocialProofGrid
    }  
  }
</script>

<style lang="scss" scoped>

</style>