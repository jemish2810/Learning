<template>
  <h3>About Cmponent</h3>
</template>
<script>
export default {
  name: "About",
};
</script>