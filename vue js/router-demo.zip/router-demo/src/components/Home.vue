<template>
  <h3>Home Cmponent</h3>
</template>
<script>
export default {
  name: "Home",
};
</script>