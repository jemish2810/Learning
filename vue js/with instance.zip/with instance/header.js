let checkbox = Vue.component('my-checkbox', {
    template: '#checkbox-template',
    data() {
        return {
            checked: false,
            title: 'Check me'
        }
    },
    methods: {
        check() {
            this.checked = !this.checked;
        }
    }
});
var app = new Vue({
    el: "#check",
    components: {
        'checkbox': checkbox,
    },
    data: {
        product: "Leaf",
        image: "./Leaf.png",
        inventory: 5
    }
})