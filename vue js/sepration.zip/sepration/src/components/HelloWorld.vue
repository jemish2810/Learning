<style src="./helloworld.css"></style>
<template src="./Helloworld.html"></template>

<script>
export default {
  name: "HelloWorld",
  data() {
    return {
      dataToPrint: "Yes data come form Hello world",
    };
  },
  props: {
    msg: String,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
