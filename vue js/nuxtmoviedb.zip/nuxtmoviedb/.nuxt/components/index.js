export { default as Logo } from '../../components/Logo.vue'
export { default as Header } from '../../components/Header/index.vue'
export { default as Movies } from '../../components/Movies/index.vue'
export { default as Notification } from '../../components/Notification/index.vue'
export { default as ProductDetailComponent } from '../../components/productDetailComponent/index.vue'

export const LazyLogo = import('../../components/Logo.vue' /* webpackChunkName: "components/Logo" */).then(c => c.default || c)
export const LazyHeader = import('../../components/Header/index.vue' /* webpackChunkName: "components/Header/index" */).then(c => c.default || c)
export const LazyMovies = import('../../components/Movies/index.vue' /* webpackChunkName: "components/Movies/index" */).then(c => c.default || c)
export const LazyNotification = import('../../components/Notification/index.vue' /* webpackChunkName: "components/Notification/index" */).then(c => c.default || c)
export const LazyProductDetailComponent = import('../../components/productDetailComponent/index.vue' /* webpackChunkName: "components/productDetailComponent/index" */).then(c => c.default || c)
