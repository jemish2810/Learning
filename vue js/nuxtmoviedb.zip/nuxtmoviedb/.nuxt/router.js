import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3f84c71a = () => interopDefault(import('../pages/about.vue' /* webpackChunkName: "pages/about" */))
const _28e444f6 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _89a08cee = () => interopDefault(import('../pages/movies/index.vue' /* webpackChunkName: "pages/movies/index" */))
const _5a462826 = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _390ee7f4 = () => interopDefault(import('../pages/movies/_id/index.vue' /* webpackChunkName: "pages/movies/_id/index" */))
const _5f3ca1df = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _3f84c71a,
    name: "about"
  }, {
    path: "/login",
    component: _28e444f6,
    name: "login"
  }, {
    path: "/movies",
    component: _89a08cee,
    name: "movies"
  }, {
    path: "/register",
    component: _5a462826,
    name: "register"
  }, {
    path: "/movies/:id",
    component: _390ee7f4,
    name: "movies-id"
  }, {
    path: "/",
    component: _5f3ca1df,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
