<template>
  <div class="row d-flex justify-content-center mt-5">
    <movieListComponent
      v-for="(data, index) in items.results"
      :id="data.id"
      :key="index"
      :poseter-path="data.poster_path"
      :release-date="data.release_date"
      :title="data.title"
    />
  </div>
</template>
<script>
import movieListComponent from '@/components/Movies'
// import { mapState, mapActions } from 'vuex'
export default {
  components: {
    movieListComponent
  },
  middleware: 'test',
  async asyncData ({ $axios }) {
    console.log('hear')
    return await $axios
      .$get(
        'https://api.themoviedb.org/3/movie/upcoming?api_key=38252124dbbb11a893376bd6da75d318&language=en-US&page=2'
      )
      .then((res) => {
        return { items: res }
      })
  }
  // async fetch () {
  //   await this.fetchMovies()
  // },
  // computed: {
  //   ...mapState('movieStore', ['movieList'])
  // },
  // methods: {
  //   ...mapActions('movieStore', ['fetchMovies'])
  // }
}
</script>
