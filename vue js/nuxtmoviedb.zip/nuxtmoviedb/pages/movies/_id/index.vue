<template>
  <client-only>
    <div class="m-5 justify-content-center">
      <NLink to="/movies">
        <b-button pill variant="dark">
          Back
        </b-button>
      </NLink>
      <ProductDetail :items="items" />
    </div>
  </client-only>
</template>

<script>
import axios from 'axios'
import ProductDetail from '@/components/productDetailComponent'
export default {
  components: {
    ProductDetail
  },
  async asyncData ({ route }) {
    const item = await axios
      .get(
        'https://api.themoviedb.org/3/movie/' +
          route.params.id +
          '?api_key=38252124dbbb11a893376bd6da75d318&language=en-US'
      )
      .then(function (res) {
        return res.data
      })
    return {
      items: item
    }
  }
}
</script>
