<template>
  <section class="section">
    <div class="container">
      <div class="columns">
        <div class="column is-4 is-offset-4">
          <h2 class="title has-text-centered">Register!</h2>

          <Notification :message="error" v-if="error"/>

          <form method="post" @submit.prevent="register">
            <div class="field">
              <label class="label">Username</label>
              <div class="control">
                <input
                  type="text"
                  class="input"
                  name="username"
                  v-model="username"
                  required
                >
              </div>
            </div>
            <div class="field">
              <label class="label">Email</label>
              <div class="control">
                <input
                  type="email"
                  class="input"
                  name="email"
                  v-model="email"
                  required
                >
              </div>
            </div>
            <div class="field">
              <label class="label">Password</label>
              <div class="control">
                <input
                  type="password"
                  class="input"
                  name="password"
                  v-model="password"
                  required
                >
              </div>
            </div>
            <div class="control">
              <button type="submit" class="button is-dark is-fullwidth">Register</button>
            </div>
          </form>

          <div class="has-text-centered" style="margin-top: 20px">
            Already got an account? <nuxt-link to="/login">Login</nuxt-link>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import Notification from '@/components/Notification'
import axios from 'axios'

export default {
  components: {
    Notification
  },

  data () {
    return {
      username: '',
      email: '',
      password: '',
      error: null
    }
  },

  methods: {
    async register () {
      try {
        const user = {
          name: this.username,
          email: this.email,
          password: this.password
        }
        // await this.$axios.post('http://127.0.0.1:8000/api/auth/signup', { data }).then((res) => {
        //   console.log(res)
        // })
        await axios({
          url: 'http://127.0.0.1:8000/api/auth/signup',
          data: user,
          method: 'POST'
        }).then((res) => {
          console.log(res)
        })

        await this.$auth.loginWith('http://127.0.0.1:8000/api/auth/login', {
          data: {
            email: this.email,
            password: this.password
          }
        })

        this.$router.push('/')
      } catch (e) {
        this.error = e.response.data.message
      }
    }
  }
}
</script>
