export default function () {
  console.log('auth middelware')
}
