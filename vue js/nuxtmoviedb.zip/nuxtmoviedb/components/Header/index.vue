/* eslint-disable vue/singleline-html-element-content-newline */
/* eslint-disable vue/html-indent */
<template>
  <b-navbar toggleable="lg" type="dark" variant="info">
    <!-- <b-navbar-brand href="/">MovieDBNuxt</b-navbar-brand> -->
    <b-navbar-toggle target="nav-collapse" />
    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <NLink to="/">
          <b-nav-item href="/">
            Home
          </b-nav-item>
        </NLink>
        <NLink to="/movies">
          <b-nav-item href="/movies">
            Movies
          </b-nav-item>
        </NLink>
        <NLink to="/about">
          <b-nav-item href="/about">
            About us
          </b-nav-item>
        </NLink>
      </b-navbar-nav>
      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <b-nav-item-dropdown right>
          <template v-slot:button-content>
            <em>User</em>
          </template>
          <b-dropdown-item href="#">
            Profile
          </b-dropdown-item>
          <b-dropdown-item href="#">
            Sign Out
          </b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</template>
