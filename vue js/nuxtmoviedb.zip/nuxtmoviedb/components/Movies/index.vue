<template>
  <div class="row m-2">
    <b-card
      :title="title"
      :img-src="
        `https://image.tmdb.org/t/p/w185_and_h278_bestv2` + poseterPath
      "
      img-alt="Image"
      img-top
      tag="article"
      style="max-width: 20rem;"
      class="mb-2"
    >
      <span class="badge badge-pill badge-info">{{ releaseDate }}</span>
      <b-card-text>
        Some quick example text to build on the card title and make up the
        bulk of the card's content.
      </b-card-text>
      <b-button variant="info" @click="$router.push('/movies/' + id)">
        More info
      </b-button>
    </b-card>
  </div>
</template>
<script>
export default {
  props: {
    // eslint-disable-next-line vue/require-default-prop
    poseterPath: {
      type: String
    },
    title: {
      type: String,
      default: 'this is title'
    },
    releaseDate: {
      type: String,
      default: '12/12/1222'
    },
    // eslint-disable-next-line vue/require-default-prop
    id: {
      type: Number
    }
  }
}
</script>
