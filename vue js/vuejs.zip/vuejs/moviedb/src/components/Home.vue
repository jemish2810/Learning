<template>
  <h3>Home component</h3>
</template>
<script>
export default {
  name: "Home",
};
</script>
