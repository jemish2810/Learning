export default {
    status: '',
    token: '',
    user: {},
}