<template>
  <form id="app" @submit="checkForm" action="/something" method="post" novalidate="true">
  
  <p v-if="errors.length">
    <b>Please correct the following error(s):</b>
    <ul>
      <li v-for="error in errors" v-bind:key="error">{{ error }}</li>
    </ul>
  </p>  

  <div class="row">
    <button class="button btn-primary" @click="addRow">+</button>
        <div class="col-12 form-group">
          <label class="col-form-label col-form-label-lg">Full Name </label>
            <input type="text" name="name" class="form-control form-control-lg" id="name" v-model="name">
        </div>
        <div class="col-12 form-group">
          <label class="col-form-label col-form-label-lg">E-mail </label>
          <!-- <input class="form-control form-control-lg" type="email" name="email" id="email" v-model="email"> -->
          <div v-for="row in rows" v-bind:key="row">
            <input type="text" class="form-control form-control-lg" id="email" v-model="email" />
            <button
              class="btn btn-info"
              v-on:click="removeElement(row);"
              style="cursor: pointer"
            >-</button>
          </div>
            <input type="submit" class="btn btn-lg col-12 btn-success" value="Submit">  
        </div>
        
  </div>  

</form>
</template>

<script>
export default {
  name: "TestCompoent",
  props: {
    msg: String,
  },
  data() {
    return {
      show:false,
     errors:[],
    name:null,
    email:null,
    rows: [{}]
    };
  },
  // watch: {
  //   email(value) {
  //     this.email = value;
  //     this.validateEmail(value);
  //   },
  // },
  methods: {
    addRow: function () {
      this.rows.push({ title: "New added", description: "New added" });
    },
    removeElement: function (row) {
      var index = this.rows.indexOf(row);
      this.rows.splice(index, 1);
    },
    checkForm:function(e) {
      this.errors = [];
      if(!this.name) this.errors.push("Name required.");
      if(!this.email) {
        this.errors.push("Email required.");
      } 
      if(!this.errors.length) return true;
      e.preventDefault();
    },
  },
};
</script>
<style scoped>

li {
  padding-top: 0px;
  margin-top: 0px;
  font-size: 12px;
  color: red;
}
form{
  height: 400px;
}

</style>
