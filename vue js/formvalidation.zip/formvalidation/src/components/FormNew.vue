<template>
  <form v-on:submit.prevent="submit">
    <div class="col-md-12">
      <label class="col-form-label col-form-label-lg">
        Full Name
        <span class="text-danger">*</span>
      </label>
      <input
        type="text"
        v-model="fname"
        class="form-control"
        :class="{ 'is-invalid': validationStatus($v.fname) }"
        placeholder="Full name"
      />
      <div v-if="!$v.fname.required" class="invalid-feedback">The full name field is required.</div>
      <div class="form-group" v-for="(row, index) in $v.rows.$each.$iter" :key="index">
        <label>E-mail {{index}}</label>
        <div :class="{ 'is-invalid': validationStatus(row.email) }">
          <div class="d-flex">
            <input
              type="email"
              v-model="row.email.$model"
              :class="{ 'is-invalid': validationStatus(row.email) }"
              class="form-control"
              placeholder="Email"
            />
            <button
              class="btn btn-danger ml-3"
              v-on:click="removeElement(row);"
              style="cursor: pointer"
            >-</button>
            <button class="btn btn-info ml-2" @click="rows.push({email: ''})">+</button>
          </div>
          <div v-if="!row.email.required" class="invalid-feedback">The Email field is required.</div>
          <div v-if="!row.email.email" class="invalid-feedback">The email is not valid.</div>
        </div>
      </div>
      <div class="col-12 form-group text-center">
        <button class="btn btn-info btn-lg col-12">Sign Up</button>
        <!-- <button class="button" @click="$v.rows.$touch">$touch</button> -->
      </div>
    </div>
  </form>
</template>
<script>
import { required, email } from "vuelidate/lib/validators";
export default {
  name: "FormNew",
  data() {
    return {
      fname: "",
      rows: [
        {
          email: "",
        },
      ],
    };
  },
  validations: {
    fname: { required },
    rows: {
      required,
      $each: {
        email: {
          required,
          email,
        },
      },
    },
  },
  methods: {
    removeElement: function (row) {
      var index = this.rows.indexOf(row);
      this.rows.splice(index, 1);
    },
    validationStatus: function (validation) {
      return typeof validation != "undefined" ? validation.$error : false;
    },
    submit: function () {
      this.$v.$touch();
      if (!this.$v.$invalid) {
        let email = this.$v.rows.$model.map((v) => {
          return v.email;
        });
        console.log("full name => " + this.$v.fname.$model);
        console.log("Email => " + email);
      }
    },
  },
};
</script>

<style scoped>
.is-invalid .invalid-feedback {
  display: block;
}
</style>