<template>
  <div>
    <table class="table">
      <thead>
        <tr>
          <td>
            <strong>Title</strong>
          </td>
          <td>
            <strong>Description</strong>
          </td>
          <td>
            <strong>File</strong>
          </td>
          <td></td>
        </tr>
      </thead>
      <tbody>
        <tr v-for="row in rows" v-bind:key="row">
          <td>
            <input type="text" v-model="row.title" />
          </td>
          <td>
            <input type="text" v-model="row.description" />
          </td>
          <td>
            <input type="file" @change="setFilename($event);" />
          </td>
          <td>
            <button
              class="btn btn-info"
              v-on:click="removeElement(row);"
              style="cursor: pointer"
            >Remove</button>
          </td>
        </tr>
      </tbody>
    </table>
    <div>
      <button class="button btn-primary" @click="addRow">Add row</button>
    </div>
  </div>
</template>
<script>
export default {
  name: "clone",
  data() {
    return {
      rows: [
        { title: "XEngine for Sale", description: "An application" },
        {
          title: "There is no place like 127.0.0.1",
          description: "Best tool for your security.",
        },
      ],
    };
  },
  methods: {
    addRow: function () {
      this.rows.push({ title: "New added", description: "New added" });
    },
    removeElement: function (row) {
      var index = this.rows.indexOf(row);
      this.rows.splice(index, 1);
    },
    setFilename: function (event) {
      this.filename = event.target.name;
    },
  },
};
</script>