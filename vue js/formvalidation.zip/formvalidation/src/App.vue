<template>
  <div id="app" class="h-100">
    <div class="container-fluid h-100">
      <div class="row h-100">
        <div class="col-md-2 vue-bg h-100 d-flex justify-content-center align-items-center">
          <img alt="Vue logo" src="./assets/logo.png" width="100" />
        </div>
        <div class="col-md-9 h-100 d-flex justify-content-center align-items-center">
          <div class="col-md-12 rounded px-5 py-4 shadow bg-white text-left">

            <!-- <TableData /> -->
            <!-- <clone /> -->

            <SignupForm />
          </div>
          <!-- <div class="col-md-6 rounded px-5 py-4 shadow bg-white text-left">
            <TestComponent />
          </div>-->
        </div>
        <!-- <div class="col-md-12 rounded px-5 py-4 shadow bg-white text-left">
          <clone />
        </div>-->
      </div>
    </div>
  </div>
</template>

<script>
import SignupForm from "./components/SignupForm";
// import TestComponent from "./components/TestComponent";
// import clone from "./components/clone";
// import FormNew from "./components/FormNew";
// import TableData from "./components/Table";

export default {
  name: "App",
  components: {
    SignupForm,
    // clone,
    // TestComponent,
    // FormNew,
    // TableData,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.vue-bg {
  background: #bce5d0;
}
</style>
