<template>
  <div>
    <b-card no-body class="overflow-hidden detail">
      <b-row no-gutters>
        <b-col md="4" class="item-img">
          <b-card-img :src="items.image" alt="Image"></b-card-img>
        </b-col>
        <b-col md="8" class="outerbody mt-5">
          <b-card-body :title="items.title">
            <b-card-text>
              <b>Product_id::</b>
              {{ items.id }}
            </b-card-text>
            <b-card-text>{{ items.description }}</b-card-text>
            <span>
              <b>Price::</b>
              $ {{ items.price }}
            </span>
            <br />
            <span>
              <b>Category::</b>
              {{ items.category }}
            </span>
            <br />
            <div class="mt-5">
              <b-button
                pill
                variant="warning"
                size="lg"
                @click="addToCartFromChild(items)"
              >
                Add to Cart
              </b-button>
              <b-button pill variant="info" size="lg">Buy now</b-button>
            </div>
          </b-card-body>
        </b-col>
      </b-row>
    </b-card>
  </div>
</template>
<script>
export default {
  name: 'ProductDetails',
  props: {
    items: {
      type: Object,
      default() {
        return {}
      },
    },
  },
  methods: {
    addToCartFromChild(data) {
      this.$emit('update-cart', data)
    },
  },
}
</script>

<style scoped>
.outerbody {
  font-size: 21px;
  color: gray;
}
.card-title {
  font-size: 24px;
  font-weight: 600;
}
.detail {
  border: none;
  border-radius: 10px;
}

.detail:hover {
  /* transform: scale(1.1); */
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23);
}
.detail .item-img img:hover {
  transform: scale(1.1);
}
.btn {
  margin-right: 10px;
}
</style>
