/* eslint-disable vue/attributes-order */
<template>
  <div class="wrapper fadeInDown">
    <div id="formContent">
      <!-- Tabs Titles -->
      <!-- Icon -->
      <div class="fadeIn first">
        <img id="icon" src="@/assets/user.png" alt="User Icon" />
      </div>
      <!-- Login Form -->
      <form @submit.prevent="sign_in">
        <input
          id="login"
          v-model="email"
          type="text"
          class="fadeIn second"
          name="login"
          placeholder="example@gmail.com"
          required
        />
        <input
          id="password"
          v-model="password"
          type="password"
          class="fadeIn third"
          name="login"
          placeholder="Password"
          required
        />
        <input type="submit" class="fadeIn fourth" value="Log In" />
        <!-- <button type="submit">Login</button> -->
      </form>

      <!-- Remind Passowrd -->
      <div id="formFooter">
        <router-link to="/signup">
          <a class="underlineHover" href="/signup">Register Now</a>
        </router-link>
        <br />
        <a class="underlineHover" href="#">Forgot Password?</a>
      </div>
    </div>
  </div>
</template>
<style src="./login.css"></style>
<script>
export default {
  name: 'Login',
  data() {
    return {
      email: '',
      password: '',
    }
  },
  computed: {},
  methods: {
    sign_in() {
      const email = this.email
      const password = this.password
      this.$store
        .dispatch('Auth/login', { email, password })
        .then(() => this.$router.push('/'))
        // eslint-disable-next-line no-console
        .catch((err) => console.log(err))
    },
  },
}
</script>
