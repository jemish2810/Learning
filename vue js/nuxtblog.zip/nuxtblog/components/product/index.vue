<template>
  <div class="product col col-lg-2">
    <nuxt-link :to="`/product/` + id">
      <div class="product-image">
        <img :src="thumbnail" />
      </div>
      <div class="title">
        <h5 class="text-center">{{ title }}</h5>
      </div>
      <p class="text-center">
        <span class="badge badge-pill badge-info">${{ price }}</span>
      </p>
      <div
        v-if="currentRouteName !== 'orders'"
        class="d-flex justify-content-center"
      >
        <!-- <nuxt-link :to="`/product/` + id">
          <b-button pill variant="outline-warning m-3">More info</b-button>
        </nuxt-link> -->
      </div>
      <div
        v-if="currentRouteName == 'orders'"
        class="d-flex justify-content-center"
      >
        <b>Qty :: {{ qty }}</b>
        <b-button
          pill
          variant="outline-danger mr-3 mb-3"
          @click="removeCartFromChild(id)"
          >Remove</b-button
        >
      </div>
    </nuxt-link>
  </div>
</template>
<script>
export default {
  name: 'Product',
  props: {
    thumbnail: {
      type: String,
      default: 'default',
    },
    title: {
      type: String,
      default: 'default',
    },
    price: {
      type: Number,
      default: 55,
    },
    id: {
      type: Number,
      default: 0,
    },
    qty: {
      type: Number,
      default: 0,
    },
  },
  computed: {
    currentRouteName() {
      return this.$route.name
    },
  },
  methods: {
    removeCartFromChild(data) {
      this.$emit('removeItem', data)
    },
  },
}
</script>

<style scoped>
.title h5 {
  width: 200px;
  margin: 0 auto;
  padding: 10px 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
a {
  color: gray;
  text-decoration: none;
}
.product {
  margin: 16px;
  padding: 0;
  /*
  width: 200px;
  height: 400px; */
  border-radius: 15px;
}
.product .product-image {
  overflow: hidden;
  border-radius: 13px 13px 0 0;
  height: 250px;
  /* max-height: 200px; */
  /* max-height: 200px; */
}

.product .product-image img {
  width: 100%;
  height: 100%;
  overflow: hidden;
  transition: transform 300ms ease-in;
  transform: scale(1);
}

@media (min-width: 991px) {
  .product .product-image img {
    min-height: 200px;
  }
}

.product .product-title {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}

.product .product-image img:hover {
  transform: scale(1.1);
}

.product .product-name {
  font-weight: normal;
  font-size: 16px;
  line-height: 20px;
  margin-bottom: 8px;
}

.product .product-price {
  font-size: 22px;
  font-weight: 700;
  line-height: 22px;
  margin-bottom: 16px;
}

.product .product-price {
  padding: 0 16px;
  text-align: center;
}

.product .product-action {
  padding: 16px;
}

.product .product-action button {
  width: 100%;
  transition: all 300ms ease-in;
  height: 25px;
  font-weight: 600;
  border-radius: 10px;
  font-size: 15px;
}

.product:hover {
  /* transform: scale(1.1); */
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23);
}

.stepper-input {
  display: flex;
  display: -webkit-flex;
  max-width: 120px;
  margin: 0 auto;
}

.stepper-input .increment,
.stepper-input .decrement {
  height: 24px;
  width: 24px;
  text-align: center;
  box-sizing: border-box;
  border-radius: 50%;
  text-decoration: none;
  color: inherit;
  font-size: 24px;
  line-height: 22px;
  -moz-user-select: none;
  -webkit-user-select: none;
}

.stepper-input .increment:active,
.stepper-input .decrement:active {
  color: gray;
}

.stepper-input .quantity {
  height: 24px;
  width: 48px;
  text-align: center;
  margin: 0 12px;
  border-radius: 5px;
}

.stepper-input .quantity:focus {
  outline: none;
}
.badge {
  font-size: 20px;
  background-color: #0b1011;
}
</style>
