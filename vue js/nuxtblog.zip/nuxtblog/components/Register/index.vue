<template>
  <div class="wrapper fadeInDown">
    <div id="formContent">
      <!-- Tabs Titles -->
      <!-- Icon -->
      <div class="fadeIn first">
        <img id="icon" src="../../assets/user2.png" alt="User Icon" />
      </div>
      <!-- Signup Form -->
      <form @submit.prevent="signup">
        <input
          id="name"
          v-model="name"
          type="text"
          class="fadeIn second"
          name="fullname"
          required
          placeholder="Full name"
        />
        <input
          id="login"
          v-model="email"
          type="text"
          class="fadeIn second"
          name="email"
          required
          placeholder="example@gmail.com"
        />
        <input
          id="password"
          v-model="password"
          type="password"
          class="fadeIn third"
          name="password"
          required
          placeholder="Password"
        />
        <input type="submit" class="fadeIn fourth" value="Register" />
      </form>
    </div>
  </div>
</template>
<script>
// import { mapActions } from 'vuex'

export default {
  name: 'Register',
  data() {
    return {
      name: '',
      email: '',
      password: '',
      password_confirmation: '',
      is_admin: null,
    }
  },
  methods: {
    signup() {
      const data = {
        name: this.name,
        email: this.email,
        password: this.password,
        is_admin: this.is_admin,
      }
      // for module
      // this.register(data)
      //   .then(() => this.$router.push('/'))
      //   .catch((err) => console.log(err))

      this.$store
        .dispatch('Auth/register', data)
        .then(() => this.$router.push('/'))
        // eslint-disable-next-line no-console
        .catch((err) => console.log(err))
    },
  },
}
</script>
