<template>
  <b-navbar toggleable="lg" type="dark" variant="info">
    <b-navbar-brand href="#">Shopify</b-navbar-brand>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <NLink to="/">
          <b-nav-item href="/">Home</b-nav-item>
        </NLink>
        <NLink to="/product">
          <b-nav-item href="/product">Products</b-nav-item>
        </NLink>
        <NLink to="/about">
          <b-nav-item href="/about">About us</b-nav-item>
        </NLink>
        <NLink to="/orders">
          <b-nav-item
            v-if="$store.state.Auth.status == 'success'"
            href="/orders"
            >My Order</b-nav-item
          >
        </NLink>
        <!-- <b-nav-item href="#" disabled>Movies</b-nav-item>
        <b-nav-item href="#" disabled>Disabled</b-nav-item>-->
      </b-navbar-nav>
      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <b-nav-item-dropdown v-if="$store.state.Auth.status == 'success'">
          <template v-slot:button-content>
            <!-- {{ $store.state.Auth.status }} -->
            <em> {{ $store.state.Auth.user.name }}</em>
          </template>
          <b-dropdown-item href="#">Profile</b-dropdown-item>
          <b-dropdown-item @click="sign_out">Sign Out</b-dropdown-item>
        </b-nav-item-dropdown>
        <div v-else>
          <NLink to="/login">
            <b-button variant="dark">login</b-button>
          </NLink>
          <!-- <NLink to="/signup">
            <b-button variant="outline-dark">sign up</b-button>
          </NLink> -->
        </div>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  name: 'Header',
  data() {
    return {
      activeClass: 'active',
      isActive: false,
    }
  },
  computed: {
    ...mapGetters('Auth', ['isLoggedIn', 'user']),
    isLoggedInfun() {
      return this.isLoggedIn
    },
    userName() {
      return this.user
    },
  },
  methods: {
    ...mapActions('Auth', ['logout']),
    sign_out() {
      this.logout().then(() => {
        this.$router.push('/login')
      })
    },
  },
}
</script>
