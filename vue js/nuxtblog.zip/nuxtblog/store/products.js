const axios = require('axios')

export const state = () => ({
  items: [],
  cart: [],
})

export const mutations = {
  set_Product(state, payload) {
    state.items = payload
  },

  set_Cart(state, payload) {
    const cart = state.cart
    const index = cart.findIndex(function (item) {
      return item.id === payload.id
    })
    if (index === -1) {
      payload.qty = 1
      state.cart.push(payload)
      return
    }
    cart[index].qty = cart[index].qty + 1
    state.cart = cart
  },

  remove_Cart(state, payload) {
    const cart = state.cart
    const cartt = cart.filter(function (item, index) {
      return item.id !== payload
    })
    state.cart = cartt
  },
}

export const actions = {
  async productInit({ commit }) {
    const res = await axios.get('https://fakestoreapi.com/products')
    const data = res.data
    commit('set_Product', data)
  },

  addToCart({ commit }, data) {
    commit('set_Cart', data)
  },

  removeFromCart({ commit }, data) {
    commit('remove_Cart', data)
    // eslint-disable-next-line no-console
    console.log('hear fun for remove cart item', data)
  },
}
