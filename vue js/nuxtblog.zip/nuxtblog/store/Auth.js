const axios = require('axios')

export const state = () => ({
  status: '',
  token: '',
  user: {},
  isLoggedIn: false,
})

export const mutations = {
  auth_request(state) {
    state.status = 'loading'
  },

  auth_success(state, { token, user }) {
    state.status = 'success'
    state.isLoggedIn = true
    state.token = token
    state.user = user
  },

  auth_error(state) {
    state.status = 'error'
  },

  logout(state) {
    state.status = ''
    state.token = ''
    state.user = ''
  },
}

export const actions = {
  async login({ commit }, user) {
    // commit('auth_request')
    return await axios({
      url: 'http://127.0.0.1:8000/api/auth/login',
      data: user,
      method: 'post',
    })
      .then((resp) => {
        const token = resp.data.access_token
        const isLogin = resp.data.isLogin
        const user = resp.data.user
        localStorage.setItem('token', token)
        localStorage.setItem('isLogin', isLogin)
        axios.defaults.headers.common.Authorization = token
        commit('auth_success', {
          token,
          user,
        })
      })
      .catch(() => {
        commit('auth_error')
        localStorage.removeItem('token')
      })
  },
  async register({ commit }, user) {
    commit('auth_request')
    return await axios({
      url: 'http://127.0.0.1:8000/api/auth/signup',
      data: user,
      method: 'POST',
    })
      .then((resp) => {
        const token = resp.data.access_token
        const isLogin = resp.data.isLogin
        const user = resp.data.user
        localStorage.setItem('token', token)
        localStorage.setItem('isLogin', isLogin)
        axios.defaults.headers.common.Authorization = token
        commit('auth_success', {
          token,
          user,
        })
      })
      .catch((err) => {
        commit('auth_error', err)
        localStorage.removeItem('token')
      })
  },
  logout({ commit }) {
    return new Promise((resolve, reject) => {
      commit('logout')
      localStorage.removeItem('token')
      localStorage.clear()
      delete axios.defaults.headers.common.Authorization
      resolve()
    })
  },
}

export const getters = (state) => ({
  isLoggedIn: (state) => !!state.token,
  authStatus: (state) => state.status,
  user: (state) => state.user,
})
