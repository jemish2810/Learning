<template>
  <div class="m-5 justify-content-center">
    <b-alert
      :show="dismissCountDown"
      dismissible
      variant="success"
      @dismissed="dismissCountDown = 0"
      @dismiss-count-down="countDownChanged"
    >
      <p>Item is added to your cart</p>
      <b-progress
        variant="success"
        :max="dismissSecs"
        :value="dismissCountDown"
        height="4px"
      ></b-progress>
    </b-alert>
    <NLink to="/product">
      <b-button pill variant="dark">Back</b-button>
    </NLink>
    <ProductDetail :items="items" @update-cart="addToCartMethod" />
  </div>
</template>

<script>
import axios from 'axios'
import { mapActions, mapState } from 'vuex'
import ProductDetail from '@/components/productDetailComponent'
export default {
  components: {
    ProductDetail,
  },
  computed: {
    ...mapState('products', ['cart']),
  },
  async asyncData(context) {
    const item = await axios
      .get('https://fakestoreapi.com/products/' + context.params.id)
      .then(function (res) {
        return res.data
      })
    return {
      items: item,
    }
  },
  data() {
    return {
      dismissSecs: 2,
      dismissCountDown: 0,
    }
  },
  methods: {
    ...mapActions('products', ['addToCart']),
    addToCartMethod(data) {
      this.addToCart(data).then(() => {
        this.dismissCountDown = this.dismissSecs
      })
    },
    countDownChanged(dismissCountDown) {
      this.dismissCountDown = dismissCountDown
    },
  },
}
</script>
