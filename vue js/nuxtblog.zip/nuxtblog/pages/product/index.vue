/* eslint-disable no-console */
<template>
  <div class="row d-flex justify-content-center">
    <Product
      v-for="(data, index) in items"
      :id="data.id"
      :key="index"
      :thumbnail="data.image"
      :price="data.price"
      :title="data.title"
    />
  </div>
</template>
<script>
import Product from '@/components/product'
import { mapState, mapActions } from 'vuex'
export default {
  name: 'Products',
  components: {
    Product,
  },
  middleware: 'test',
  async fetch() {
    await this.productInit()
  },
  computed: {
    ...mapState('products', ['items']),
  },
  methods: {
    ...mapActions('products', ['productInit']),
  },
}
</script>
