<template>
  <LoginComponent />
</template>
<script>
import LoginComponent from '@/components/Login'
export default {
  components: {
    LoginComponent,
  },
}
</script>
