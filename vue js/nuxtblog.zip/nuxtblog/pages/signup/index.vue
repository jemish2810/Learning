<template>
  <SignupComponent />
</template>
<script>
import SignupComponent from '@/components/Register'
export default {
  components: {
    SignupComponent,
  },
}
</script>
