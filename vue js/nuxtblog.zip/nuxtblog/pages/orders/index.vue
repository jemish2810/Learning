<template>
  <div>
    <div class="card-header m-3">
      Myorder List
    </div>
    <b-alert
      class="ml-3 col-md-8"
      :show="dismissCountDown"
      dismissible
      variant="danger"
      @dismissed="dismissCountDown = 0"
      @dismiss-count-down="countDownChanged"
    >
      <p>Item is deleted from your cart</p>
      <b-progress
        variant="danger"
        :max="dismissSecs"
        :value="dismissCountDown"
        height="4px"
      ></b-progress>
    </b-alert>
    <div class="row d-flex justify-content-center">
      <Product
        v-for="(data, index) in cart"
        :id="data.id"
        :key="index"
        :thumbnail="data.image"
        :price="data.price"
        :title="data.title"
        :qty="data.qty"
        @removeItem="removeCartProduct"
      />
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'

import Product from '@/components/product'

export default {
  components: {
    Product,
  },
  data() {
    return {
      dismissSecs: 2,
      dismissCountDown: 0,
    }
  },
  computed: {
    ...mapState('products', ['cart']),
  },
  methods: {
    ...mapActions('products', ['removeFromCart']),

    removeCartProduct(data) {
      this.removeFromCart(data).then(() => {
        this.dismissCountDown = this.dismissSecs
      })
      // this.$store.dispatch('products/removeFromCart', data)
    },
    countDownChanged(dismissCountDown) {
      this.dismissCountDown = dismissCountDown
    },
  },
}
</script>
