<template>
  <div>
    <h1>about page</h1>
  </div>
</template>
<script>
export default {
  middleware: 'test',
}
</script>
