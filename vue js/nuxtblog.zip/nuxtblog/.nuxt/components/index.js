export { default as Logo } from '../../components/Logo.vue'
export { default as Header } from '../../components/Header/index.vue'
export { default as Login } from '../../components/Login/index.vue'
export { default as Register } from '../../components/Register/index.vue'
export { default as Product } from '../../components/product/index.vue'
export { default as ProductDetailComponent } from '../../components/productDetailComponent/index.vue'

export const LazyLogo = import('../../components/Logo.vue' /* webpackChunkName: "components/Logo" */).then(c => c.default || c)
export const LazyHeader = import('../../components/Header/index.vue' /* webpackChunkName: "components/Header/index" */).then(c => c.default || c)
export const LazyLogin = import('../../components/Login/index.vue' /* webpackChunkName: "components/Login/index" */).then(c => c.default || c)
export const LazyRegister = import('../../components/Register/index.vue' /* webpackChunkName: "components/Register/index" */).then(c => c.default || c)
export const LazyProduct = import('../../components/product/index.vue' /* webpackChunkName: "components/product/index" */).then(c => c.default || c)
export const LazyProductDetailComponent = import('../../components/productDetailComponent/index.vue' /* webpackChunkName: "components/productDetailComponent/index" */).then(c => c.default || c)
