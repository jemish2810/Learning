export default function ({ store, redirect }) {
  console.log('auth middelware', store.state.Auth.isLoggedIn)
  if (!store.state.Auth.isLoggedIn) {
    return redirect('/login')
  }
}
