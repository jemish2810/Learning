<template>
  <div>
    <product-list />
  </div>
</template>

<script>
import ProductList from "../components/ProductList";
export default {
  components: {
    ProductList
  }
};
</script>

<style>
</style>