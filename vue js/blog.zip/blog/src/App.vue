<template>
  <div id="app">
    <!-- <img alt="Vue logo" src="./assets/logo.png" /> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js App" /> -->
    <!-- <Home data="some data pass to home " /> -->
    <!-- <Header /> -->
    <!-- <DataBind /> -->
    <h3>{{title}}</h3>
    <Child v-on:changeTitle="updateTitleText($event)" />
  </div>
</template>

<script>
// import HelloWorld from "./components/HelloWorld.vue";
// import Home from "./components/Home.vue";
// import Header from "./components/Header.vue";
// import DataBind from "./components/DataBind";
import Child from "./components/Child";

export default {
  name: "App",
  components: {
    // HelloWorld,
    // Home,
    // Header,
    // DataBind,
    Child,
  },
  data() {
    return {
      title: "child to perent change text",
      property: "initially",
    };
  },
  methods: {
    updateTitleText(title) {
      this.title = title;
    },
  },
  beforeCreate() {
    console.log("Nothing gets called beforeCreate!");
  },
  created() {
    this.property = "Example property update.";
    console.log(
      "propertyComputed will update, as this.property is now reactive.",
      this.property
    );
    console.log("Nothing gets called created!");
  },
  beforeMount() {
    // console.log("updated data in before mount::", this.property);
    console.log("Nothing gets called beforeMount!");
  },
  mounted() {
    console.log("Nothing gets called mounted!");
  },
  beforeUpdate() {
    console.log("Nothing gets called beforeUpdate!");

    console.log(this.property); // Logs the counter value every second, before the DOM updates.
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  /* margin-top: 60px; */
}
</style>
