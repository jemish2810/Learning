<template>
  <div class="maindiv">
    <h3>Data Binding</h3>
    <div>
      <b>
        <p>Demo 1</p>
      </b>
      <input type="text" v-model="message" />
      <p v-bind:style="{ color: 'red' }">{{ message }}</p>
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 2</p>
      </b>
      <!-- <h4 v-else>conditional rendering else</h4> -->
      <button v-on:click="toggle">toggle</button>
      <!-- <button v-on:click="error= !error">show</button>
      <button v-on:click="success = !success">hide</button>
      <h4 v-show="error"> rendering error</h4>
      <h4 v-show="success"> rendering success</h4>-->
      <button v-on:click="showBtn(1)">show</button>
      <button v-on:click="showBtn(0)">hide</button>
      <h4 v-if="showText">show hide with 2 btn</h4>
      <h4 v-if="show">show hide with toggle conditional rendering if</h4>
      <h4 v-else>show hide with toggle conditional rendering else</h4>
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 3</p>
      </b>
      <label>price</label>
      <input type="number" placeholder="Enter Price" v-model="price" />
      *
      <label>qty</label>
      <input type="number" placeholder="Enter Qty" v-model="qty" />=
      <label for="result"></label>
      <input type="text" placeholder="Result" id="result" v-model="result" />
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 4</p>
      </b>
      <label>celsius</label>
      <input type="number" placeholder="Enter Price" v-model="cel" />
      =
      <label>Fahrenheit</label>
      <input type="number" placeholder="Enter Qty" v-model="convert" />
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 5</p>
      </b>
      <div class="col-sm-4">
        <select v-model="selected">
          <!-- <select
          name="selectType"
          class="form-control form-control-sm"
          @change="onChange($event)"
          v-model="key"
          >-->
          <option disabled value>Please select one</option>
          <option value="time">time</option>
          <option value="temp">temp</option>
        </select>
      </div>
      <br />
      <div v-if="this.selected == 'temp'">
        <!-- <div v-if="this.temp"> -->
        <label>celsius</label>
        <input type="number" placeholder="Enter Price" v-model="cel" />
        =
        <label>Fahrenheit</label>
        <input type="number" placeholder="Enter Qty" v-model="convert" />
      </div>
      <!-- <div v-if="this.time"> -->
      <div v-if="this.selected == 'time'">
        <label>sec</label>
        <input type="number" v-model="sec" />
        =
        <label>min</label>
        <input type="number" v-model="converttime" />
      </div>
      <hr />
      <div>
        <b>
          <p>Demo 6</p>
        </b>
        Red :
        <span id="rv">{{red}}</span>
        <input type="range" id="red" min="0" max="255" v-model="red" />
        Green :
        <span id="gv">{{green}}</span>
        <input type="range" id="green" min="0" max="255" v-model="green" />
        Blue :
        <span id="bv">{{blue}}</span>
        <input type="range" id="blue" min="0" max="255" v-model="blue" />
        <input type="text" id="display" v-bind:style="{ 'background-color': color }" disabled />
      </div>
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 7</p>
      </b>
      <ul>
        <li v-for="list in lists" v-bind:key="list.id">{{ list.name }}</li>
      </ul>
      <div id="listDemo">
        <input v-model="addNew.name" class="form-control" placeholder="Enter value " />
      </div>
      <div id="btn">
        <button type="submit" v-on:click="addNewUser(0)" id="new" class="btn btn-info">Add Default</button>
        <button type="submit" v-on:click="addNewUser(1)" id="default" class="btn btn-success">Add</button>
      </div>
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 8</p>
      </b>

      <div class="mainBox">
        <button type="submit" v-on:click="val += 1" id="new" class="btn btn-info">+</button>
        <!-- <button type="submit" v-on:click="inc_dec(0)" id="new" class="btn btn-info">+</button> -->
        <div id="result">{{val}}</div>
        <button type="submit" v-on:click="val -= 1" id="default" class="btn btn-info">-</button>
        <!-- <button type="submit" v-on:click="inc_dec(1)" id="default" class="btn btn-info">-</button> -->
      </div>
    </div>
    <hr />
    <div>
      <b>
        <p>Demo 9</p>
      </b>
      <button type="submit" id="new" v-on:click="addComponent += 1" class="btn btn-warning">Add New</button>
      <div class="cloneComponent" v-for="val in addComponent" v-bind:key="val.index">
        <Clone />
      </div>
    </div>
  </div>
</template>
<script>
import Clone from "./Clone";
export default {
  name: "DataBind",
  components: { Clone },
  data() {
    return {
      show: false,
      message: "",
      showText: false,
      error: false,
      success: false,
      price: "",
      qty: "",
      cel: 0,
      feh: 0,
      key: "",
      temp: false,
      time: true,
      sec: 0,
      min: 0,
      red: 0,
      green: 0,
      blue: 0,
      selected: "",
      opacity: 100,
      lists: [
        { id: 0, name: "Tea" },
        { id: 1, name: "Milk" },
      ],
      addNew: { id: "", name: "", default: "coffee" },
      val: 0,
      addComponent: 0,
    };
  },
  computed: {
    result: function () {
      return this.price * this.qty;
    },
    convert: {
      get: function () {
        // let feh = (this.cel * 9) / 5 + 32;
        return Math.round((this.cel * 9) / 5 + 32);
      },
      set: function (newValue) {
        this.cel = ((newValue - 32) * 5) / 9;
        return Math.round(this.cel);
      },
    },
    converttime: {
      get: function () {
        return this.sec / 60;
      },
      set: function (newValue) {
        this.sec = newValue * 60;
        return Math.round(this.sec);
      },
    },
    color: function () {
      return (
        "rgba(" +
        this.red +
        ", " +
        this.green +
        ", " +
        this.blue +
        ", " +
        this.opacity / 100 +
        ")"
      );
    },
  },
  methods: {
    toggle() {
      this.show = !this.show;
    },
    showBtn(val) {
      val == 1 ? (this.showText = true) : (this.showText = false);
    },
    // showBtn(val) {
    //   this.showText = true;
    // },
    // hideBtn() {
    //   this.showText = false;
    // },
    onChange(event) {
      if (event.target.value == 1) {
        this.temp = false;
        this.time = true;
      } else {
        this.temp = true;
        this.time = false;
      }
    },
    addNewUser(val) {
      if (val == 0) {
        this.lists.push({ name: this.addNew.default });
      } else {
        this.lists.push({ name: this.addNew.name });
      }
    },
    inc_dec(e) {
      if (e == 0) {
        this.val = this.val + 1;
      } else {
        this.val = this.val - 1;
      }
    },
    clone() {
      this.inputs.push({
        id: `fruit${++this.counter}`,
        label: "Enter Fruit Name",
        value: "",
      });
    },
  },
};
</script>
<style scoped>
h3 {
  background-color: cadetblue;
  color: darkslategray;
  text-align: center;
}
.maindiv {
  margin: 25px;
}
#display {
  width: 350px;
  height: 75px;
  /* border: 1px solid black; */
  border-radius: 10px;
  margin-top: 25px;
  /* background-color: rgb(0, 0, 0); */
  box-shadow: 5px 5px 5px grey;
}
#listDemo {
  width: 30%;
  display: flex;
}
#btn button {
  margin: 15px 2px 0px;
}
#result {
  width: 30px;
  margin: 1px;
  padding: 5px;
  text-align: center;
}
.mainBox {
  background-color: black;
  color: white;
  width: 18xpx;
  width: 110px;
  padding: 5px;
  border-radius: 10px;
  display: inline-flex;
}
.cloneComponent {
  display: inline-flex;
  margin: 5px;
}
</style>
