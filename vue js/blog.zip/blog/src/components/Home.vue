<template>
  <div>
    <h3>Hello</h3>
    <h3>{{ data }}</h3>
    <button v-on:click="first_fun('click')">call fun on click</button>
    <button v-on:mouseover="first_fun('hover')">call fun on hover</button>

    <!-- conditonal rendering  -->
    <h4 v-if="show">conditional rendering if</h4>
    <h4 v-else>conditional rendering else</h4>
    <!-- toggle btn  -->
    <button v-on:click="toggle">toggle</button>
    <button v-bind:disabled="disableBtn">toggle disableBtn</button>
    <!-- update name -->
    <h3 v-once>{{ name }}</h3>
    <h3>{{ name }}</h3>
    <button v-on:click="update">update name</button>
    <!-- for loop -->
    <div class="forloop">
      <h1>for loop</h1>
      <table border="1px">
        <tr>
          <td>id</td>
          <td>name</td>
        </tr>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.id }}</td>
          <td>{{ user.name }}</td>
        </tr>
      </table>

      <div class="ulclass">
        <ul>
          <li v-for="todo in todos" :key="todo.id">{{ todo.text }}</li>
        </ul>
      </div>
    </div>

    <h3 class="homeStyle">class and style binding</h3>
    <h3 v-bind:style="{ color: 'blue' }">style binding in tag</h3>
    <h3 v-bind:class="{ display: true, displayColor: colorShow }">class style binding with object</h3>
    <h3 v-bind:class="['arrayClass']">class style binding with array</h3>
    <h3
      v-bind:class="[show ? 'ysearrayClass' : 'noarrayClass']"
    >class style binding with array condition</h3>
  </div>
</template>
<script>
export default {
  name: "Home",
  props: {
    data: String,
    msg: String,
  },
  data() {
    return {
      show: false,
      name: "Test name",
      disableBtn: true,
      colorShow: true,
      users: [
        { id: 1, name: "abc" },
        { id: 2, name: "abcd" },
        { id: 3, name: "abcde" },
        { id: 4, name: "abcdef" },
        { id: 5, name: "abcdefg" },
      ],
      todos: [
        { text: "Learn JavaScript" },
        { text: "Learn Vue.js" },
        { text: "Something Awesome" },
      ],
    };
  },
  methods: {
    first_fun(val) {
      console.log("log for button", val);
    },
    toggle() {
      this.show = !this.show;
    },
    update() {
      this.name = "updated name";
    },
  },
};
</script>
<style scoped>
.homeStyle {
  color: orange;
}
.display {
  background-color: bisque;
}
.displayColor {
  color: darkcyan;
}
.arrayClass {
  color: brown;
}
.forloop {
  flex-direction: column;
}
.ulclass {
  width: 200px;
}
.ysearrayClass {
  color: saddlebrown;
}
.noarrayClass {
  color: teal;
}
</style>
