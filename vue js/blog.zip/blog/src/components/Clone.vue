<template>
  <div class="mainBox">
    <button type="submit" v-on:click="val += 1" id="new" class="btn btn-info">+</button>
    <!-- <button type="submit" v-on:click="inc_dec(0)" id="new" class="btn btn-info">+</button> -->
    <div id="result">{{val}}</div>
    <button type="submit" v-on:click="val -= 1" id="default" class="btn btn-info">-</button>
    <!-- <button type="submit" v-on:click="inc_dec(1)" id="default" class="btn btn-info">-</button> -->
  </div>
</template>

<script>
export default {
  name: "Clone",
  data() {
    return {
      val: 0,
    };
  },
};
</script>
<style scoped>
#btn button {
  margin: 15px 2px 0px;
}
#result {
  width: 30px;
  margin: 1px;
  padding: 5px;
  text-align: center;
}
.mainBox {
  background-color: black;
  color: white;
  width: 18xpx;
  width: 110px;
  padding: 5px;
  border-radius: 10px;
  display: inline-flex;
}
</style>