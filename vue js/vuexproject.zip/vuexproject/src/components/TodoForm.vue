<template>
  <div class="d-inline-flex justify-content-center">
    <div class="card text-white bg-dark mb-3 " style="width: 18rem;">
      <div class="card-body">
        <h5 class="card-title"><b>Form</b></h5>
        <div>
          <input
            type="text"
            class="form-control col-12 mb-2 "
            v-model="newItem"
          />
          <button
            type="submit"
            class="btn btn-outline-info"
            @click="addnewItem()"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      newItem: "",
    };
  },
  methods: {
    addnewItem() {
      // this.$store.dispatch("addnewItem", this.newItem);
      this.$store.commit("NEW_TODO", this.newItem);
      this.newItem = "";
    },
  },
};
</script>
