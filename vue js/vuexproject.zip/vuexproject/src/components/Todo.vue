<template>
  <div class="todos" style="width:250px; margin:5px auto;">
    <div style="display:flex; justify-content:space-between">
      <span
        :class="{ completed: todo.completed }"
        @click="toggleTodoStatus(todo)"
      >
        {{ todo.title }}</span
      >
      <button
        class=" btn btn-outline-danger btn-group-sm"
        @click="deletetodo(todo)"
      >
        Del
      </button>
    </div>
  </div>
</template>
<script>
// import { mapMutations } from "vuex";
import { mapActions } from "vuex";
export default {
  props: ["todo"],
  methods: {
    // 1st way call action method and dispatch this.todos
    // deletetodo() {
    //   // this.$store.dispatch("deleteTodo", this.todos);
    // 2nd way call directly Mutations method and commit this.todos
    //   this.$store.commit("DELETE_TODO", this.todos);
    // },
    // toggleTodoStatus() {
    //   this.$store.commit("TOGGLE_STATUS", this.todos);
    //   //   this.$store.dispatch("toggleTodoStatus", this.todos);
    // },

    // 3rd way mapaction
    // use map action with dispetch fun name
    ...mapActions({
      deletetodo: "deleteTodo",
      toggleTodoStatus: "toggleTodoStatus",
    }),

    // 4rth way use directly mapMutations
    // ...mapMutations({
    //   deletetodo: "DELETE_TODO",
    //   toggleTodoStatus: "TOGGLE_STATUS",
    // }),
  },
};
</script>
<style scoped>
.completed {
  color: brown;
  text-decoration: line-through;
}
</style>
