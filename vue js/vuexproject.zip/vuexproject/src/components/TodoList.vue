<template>
  <div>
    <h3>To do list</h3>
    <!-- <Todo v-for="(todo,index) in $store.state.todos" :key="index" /> -->
    <Todo v-for="(todo, index) in Todos" :key="index" :todo="todo" />
  </div>
</template>
<script>
import Todo from "./Todo";
import { mapState } from "vuex";
export default {
  components: {
    Todo,
  },
  computed: {
    // todos() {
    //   return this.$store.state.todos;
    // },

    // we can do above function like below
    ...mapState({
      Todos: "todos",
    }),
  },
};
</script>
