<template>
  <div id="Todo">
    <!-- <h3>completed:{{ $store.getters.completedTodos }}</h3>
    <h3>pending:{{ $store.getters.pendingTodos }}</h3>-->
    <div class="d-flex justify-content-center">
      <h5 class="mr-3">
        <b>Completed:</b>
        {{ completedTodos }}
      </h5>
      <h5>
        <b>pending:</b>
        {{ pendingTodos }}
      </h5>
    </div>
    <TodoList />
    <TodoForm />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import TodoList from "./TodoList.vue";
import TodoForm from "./TodoForm.vue";

export default {
  name: "TodoMain",
  components: {
    TodoList,
    TodoForm,
  },
  computed: {
    // completedTodos() {
    //   return this.$state.getters.completedTodos;
    // },
    // pendingTodos() {
    //   return this.$state.getters.pendingTodos;
    // },

    // we can wrap getters method like this.

    ...mapGetters({
      completedTodos: "completedTodos",
      pendingTodos: "pendingTodos",
    }),
  },
};
</script>
